import axios from 'axios';

// Base URL của JSON Server (đọc từ .env)
const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

// Google API Key (đọc từ .env)
export const GOOGLE_API_KEY = process.env.REACT_APP_GOOGLE_API_KEY;

// Tạo axios instance với config mặc định
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 8000,
  headers: { 'Content-Type': 'application/json' },
});

// ========== PRODUCTS API ==========
export const productsApi = {
  /** Lấy tất cả sản phẩm (có thể lọc, sắp xếp) */
  getAll: (params = {}) => api.get('/products', { params }),

  /** Lấy một sản phẩm theo ID */
  getById: (id) => api.get(`/products/${id}`),

  /** Thêm sản phẩm mới */
  create: (data) => api.post('/products', {
    ...data,
    createdAt: new Date().toISOString().split('T')[0]
  }),

  /** Cập nhật sản phẩm */
  update: (id, data) => api.put(`/products/${id}`, data),

  /** Xoá sản phẩm */
  delete: (id) => api.delete(`/products/${id}`),
};

// ========== ORDERS API ==========
export const ordersApi = {
  /** Lấy tất cả đơn hàng */
  getAll: (params = {}) => api.get('/orders', { params }),

  /** Lấy một đơn hàng */
  getById: (id) => api.get(`/orders/${id}`),

  /** Tạo đơn hàng mới */
  create: (data) => api.post('/orders', {
    ...data,
    createdAt: new Date().toISOString().split('T')[0]
  }),

  /** Cập nhật đơn hàng (đổi status, ...) */
  update: (id, data) => api.put(`/orders/${id}`, data),

  /** Xoá đơn hàng */
  delete: (id) => api.delete(`/orders/${id}`),
};

// ========== CUSTOMERS API ==========
export const customersApi = {
  /** Lấy tất cả khách hàng */
  getAll: (params = {}) => api.get('/customers', { params }),

  /** Lấy một khách hàng */
  getById: (id) => api.get(`/customers/${id}`),

  /** Thêm khách hàng mới */
  create: (data) => api.post('/customers', {
    ...data,
    createdAt: new Date().toISOString().split('T')[0]
  }),

  /** Cập nhật khách hàng */
  update: (id, data) => api.put(`/customers/${id}`, data),

  /** Xoá khách hàng */
  delete: (id) => api.delete(`/customers/${id}`),
};

// ========== VOUCHERS API ==========
export const vouchersApi = {
  /** Lấy tất cả voucher */
  getAll: (params = {}) => api.get('/vouchers', { params }),

  /** Lấy một voucher theo ID */
  getById: (id) => api.get(`/vouchers/${id}`),

  /** Tìm voucher theo mã code */
  getByCode: (code) => api.get('/vouchers', { params: { code } }),

  /** Tạo voucher mới */
  create: (data) => api.post('/vouchers', {
    ...data,
    createdAt: new Date().toISOString().split('T')[0]
  }),

  /** Cập nhật voucher (toàn bộ) */
  update: (id, data) => api.put(`/vouchers/${id}`, data),

  /** Cập nhật một phần voucher (đánh dấu đã dùng, ...) */
  patch: (id, data) => api.patch(`/vouchers/${id}`, data),

  /** Xoá voucher */
  delete: (id) => api.delete(`/vouchers/${id}`),
};

export default api;
