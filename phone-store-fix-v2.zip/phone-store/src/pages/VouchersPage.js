import React, { useEffect, useState, useMemo } from 'react';
import { vouchersApi, customersApi } from '../services/api';
import { formatCurrency, formatDate } from '../utils/format';
import Loading from '../components/Loading';
import ConfirmDialog from '../components/ConfirmDialog';
import Pagination from '../components/Pagination';
import toast from 'react-hot-toast';

// Các mốc gợi ý trên slider
const PERCENT_MILESTONES = [5, 10, 15, 20, 25, 30, 40, 50, 75, 100];

// Tự sinh mã voucher
function generateCode(percent, customerName) {
  const initials = customerName
    .split(' ')
    .map(w => w.charAt(0).toUpperCase())
    .join('')
    .slice(0, 3);
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `SALE${percent}-${initials}-${rand}`;
}

// Kiểm tra trạng thái voucher
function getVoucherStatus(v) {
  if (v.isUsed) return { label: 'Đã dùng', cls: 'badge-gray' };
  if (new Date(v.expiryDate) < new Date()) return { label: 'Hết hạn', cls: 'badge-danger' };
  return { label: 'Khả dụng', cls: 'badge-success' };
}

const ITEMS_PER_PAGE = 8;

export default function VouchersPage() {
  const [vouchers, setVouchers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);

  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    code: '',
    discountPercent: 10,
    maxDiscount: '',
    minOrderValue: '',
    customerId: '',
    customerName: '',
    expiryDate: '',
    note: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // Delete confirm
  const [deleteId, setDeleteId] = useState(null);

  // Fetch data
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [vRes, cRes] = await Promise.all([
        vouchersApi.getAll(),
        customersApi.getAll()
      ]);
      setVouchers(vRes.data);
      setCustomers(cRes.data);
    } catch (err) {
      toast.error('Lỗi khi tải dữ liệu');
    } finally {
      setLoading(false);
    }
  };

  // Customer lookup map: luôn hiển thị tên mới nhất từ bảng customers
  const customerMap = useMemo(() => {
    const map = {};
    customers.forEach(c => { map[String(c.id)] = c.name; });
    return map;
  }, [customers]);

  // Lấy tên KH mới nhất, fallback về tên lưu trong voucher
  const getCustomerName = (v) => customerMap[String(v.customerId)] || v.customerName;

  // Filter & search
  const filtered = useMemo(() => {
    let list = [...vouchers];

    // Search
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(v =>
        v.code.toLowerCase().includes(q) ||
        getCustomerName(v).toLowerCase().includes(q)
      );
    }

    // Filter status
    if (filterStatus === 'available') {
      list = list.filter(v => !v.isUsed && new Date(v.expiryDate) >= new Date());
    } else if (filterStatus === 'used') {
      list = list.filter(v => v.isUsed);
    } else if (filterStatus === 'expired') {
      list = list.filter(v => !v.isUsed && new Date(v.expiryDate) < new Date());
    }

    // Sort: newest first
    list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return list;
    // eslint-disable-next-line
  }, [vouchers, search, filterStatus, customerMap]);

  // Pagination
  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paged = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  // Open modal
  const openCreateModal = () => {
    const defaultDate = new Date();
    defaultDate.setMonth(defaultDate.getMonth() + 3);
    setFormData({
      code: '',
      discountPercent: 10,
      maxDiscount: '',
      minOrderValue: '',
      customerId: '',
      customerName: '',
      expiryDate: defaultDate.toISOString().split('T')[0],
      note: ''
    });
    setFormErrors({});
    setShowModal(true);
  };

  // Handle customer select
  const handleCustomerChange = (customerId) => {
    const cust = customers.find(c => String(c.id) === String(customerId));
    const name = cust ? cust.name : '';
    const percent = formData.discountPercent;
    setFormData(prev => ({
      ...prev,
      customerId: customerId,
      customerName: name,
      code: name ? generateCode(percent, name) : ''
    }));
  };

  // Handle percent change
  const handlePercentChange = (val) => {
    const percent = Math.max(1, Math.min(100, Number(val) || 1));
    setFormData(prev => ({
      ...prev,
      discountPercent: percent,
      code: prev.customerName ? generateCode(percent, prev.customerName) : prev.code
    }));
  };

  // Validate form
  const validateForm = () => {
    const errors = {};
    if (!formData.customerId) errors.customerId = 'Vui lòng chọn khách hàng';
    if (!formData.code.trim()) errors.code = 'Mã không được trống';
    if (formData.discountPercent < 1 || formData.discountPercent > 100) errors.discountPercent = 'Phần trăm từ 1-100';
    if (!formData.expiryDate) errors.expiryDate = 'Chọn hạn sử dụng';
    // Check duplicate code
    if (vouchers.some(v => v.code.toUpperCase() === formData.code.trim().toUpperCase())) {
      errors.code = 'Mã này đã tồn tại';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Save voucher
  const handleSave = async () => {
    if (!validateForm()) return;
    setSaving(true);
    try {
      const payload = {
        code: formData.code.trim().toUpperCase(),
        discountPercent: formData.discountPercent,
        maxDiscount: formData.maxDiscount ? Number(formData.maxDiscount) : null,
        minOrderValue: formData.minOrderValue ? Number(formData.minOrderValue) : 0,
        customerId: formData.customerId,
        customerName: formData.customerName,
        isUsed: false,
        usedAt: null,
        orderId: null,
        expiryDate: formData.expiryDate,
        note: formData.note.trim()
      };
      await vouchersApi.create(payload);
      toast.success(`Tạo voucher ${payload.code} thành công!`);
      setShowModal(false);
      fetchData();
    } catch (err) {
      toast.error('Lỗi khi tạo voucher');
    } finally {
      setSaving(false);
    }
  };

  // Delete voucher
  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await vouchersApi.delete(deleteId);
      toast.success('Đã xóa voucher');
      setDeleteId(null);
      fetchData();
    } catch (err) {
      toast.error('Lỗi khi xóa voucher');
    }
  };

  if (loading) return <Loading text="Đang tải danh sách voucher..." />;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Quản lý Mã giảm giá</div>
          <div className="page-subtitle">Tạo và quản lý voucher cho từng khách hàng</div>
        </div>
        <button className="btn btn-primary" onClick={openCreateModal}>
          + Tạo Voucher
        </button>
      </div>

      {/* Stats summary */}
      <div className="stats-grid" style={{ marginBottom: 24 }}>
        <div className="stat-card green">
          <div className="stat-value">{vouchers.filter(v => !v.isUsed && new Date(v.expiryDate) >= new Date()).length}</div>
          <div className="stat-label">Đang khả dụng</div>
        </div>
        <div className="stat-card orange">
          <div className="stat-value">{vouchers.filter(v => v.isUsed).length}</div>
          <div className="stat-label">Đã sử dụng</div>
        </div>
        <div className="stat-card purple">
          <div className="stat-value">{vouchers.filter(v => !v.isUsed && new Date(v.expiryDate) < new Date()).length}</div>
          <div className="stat-label">Hết hạn</div>
        </div>
        <div className="stat-card blue">
          <div className="stat-value">{vouchers.length}</div>
          <div className="stat-label">Tổng voucher</div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="toolbar">
        <div className="search-box">
          <span className="search-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          </span>
          <input
            type="text"
            placeholder="Tìm theo mã hoặc tên khách hàng..."
            value={search}
            onChange={e => { setSearch(e.target.value); setCurrentPage(1); }}
          />
        </div>
        <select
          className="filter-select"
          value={filterStatus}
          onChange={e => { setFilterStatus(e.target.value); setCurrentPage(1); }}
        >
          <option value="all">Tất cả</option>
          <option value="available">Khả dụng</option>
          <option value="used">Đã dùng</option>
          <option value="expired">Hết hạn</option>
        </select>
      </div>

      {/* Table */}
      <div className="card">
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Mã Voucher</th>
                <th>Khách hàng</th>
                <th>Giảm %</th>
                <th>Giảm tối đa</th>
                <th>Đơn tối thiểu</th>
                <th>Hạn sử dụng</th>
                <th>Trạng thái</th>
                <th style={{ textAlign: 'center' }}>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td colSpan="8">
                    <div className="empty-state">
                      <h3>Không có voucher nào</h3>
                      <p>Tạo voucher mới để bắt đầu</p>
                    </div>
                  </td>
                </tr>
              ) : paged.map(v => {
                const status = getVoucherStatus(v);
                return (
                  <tr key={v.id}>
                    <td className="primary">
                      <code style={{
                        background: 'var(--accent-light)',
                        color: 'var(--accent)',
                        padding: '4px 10px',
                        borderRadius: 6,
                        fontFamily: 'var(--font-mono)',
                        fontSize: 13,
                        fontWeight: 700,
                        letterSpacing: 0.5
                      }}>{v.code}</code>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{getCustomerName(v)}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>ID: {v.customerId}</div>
                    </td>
                    <td>
                      <span style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: `hsl(${120 - v.discountPercent * 1.2}, 80%, 95%)`,
                        color: `hsl(${120 - v.discountPercent * 1.2}, 70%, 35%)`,
                        fontWeight: 800,
                        fontSize: 15,
                        padding: '4px 12px',
                        borderRadius: 8,
                        fontFamily: 'var(--font-mono)'
                      }}>
                        -{v.discountPercent}%
                      </span>
                    </td>
                    <td>{v.maxDiscount ? formatCurrency(v.maxDiscount) : <span style={{ color: 'var(--text-muted)' }}>Không giới hạn</span>}</td>
                    <td>{v.minOrderValue > 0 ? formatCurrency(v.minOrderValue) : <span style={{ color: 'var(--text-muted)' }}>Không</span>}</td>
                    <td>{formatDate(v.expiryDate)}</td>
                    <td>
                      <span className={`badge ${status.cls}`}>{status.label}</span>
                      {v.isUsed && v.usedAt && (
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                          Ngày {formatDate(v.usedAt)}
                        </div>
                      )}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      {!v.isUsed ? (
                        <button
                          className="btn-icon danger"
                          title="Xóa"
                          onClick={() => setDeleteId(v.id)}
                          style={{ width: 34, height: 34, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                        </button>
                      ) : (
                        <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <Pagination
            page={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            total={filtered.length}
            pageSize={ITEMS_PER_PAGE}
          />
        )}
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">Tạo Voucher mới</h3>
              <button className="modal-close" onClick={() => setShowModal(false)}>&times;</button>
            </div>
            <div className="modal-body">
              {/* Chọn khách hàng */}
              <div className="form-group">
                <label className="form-label">Khách hàng <span>*</span></label>
                <select
                  className={`form-control ${formErrors.customerId ? 'is-invalid' : ''}`}
                  value={formData.customerId}
                  onChange={e => handleCustomerChange(e.target.value)}
                >
                  <option value="">-- Chọn khách hàng --</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name} — {c.phone || c.email}</option>
                  ))}
                </select>
                {formErrors.customerId && <span className="error-text text-danger" style={{ fontSize: 12, marginTop: 4, display: 'block' }}>{formErrors.customerId}</span>}
              </div>

              {/* Phần trăm giảm giá */}
              <div className="form-group">
                <label className="form-label">Phần trăm giảm giá <span>*</span></label>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <div style={{ flex: 1 }}>
                    <input
                      type="range"
                      min="1"
                      max="100"
                      value={formData.discountPercent}
                      onChange={e => handlePercentChange(e.target.value)}
                      className="voucher-slider"
                      style={{
                        width: '100%',
                        height: 8,
                        borderRadius: 4,
                        outline: 'none',
                        appearance: 'none',
                        background: `linear-gradient(to right, var(--accent) 0%, var(--accent) ${formData.discountPercent}%, var(--border) ${formData.discountPercent}%, var(--border) 100%)`,
                        cursor: 'pointer'
                      }}
                    />
                    {/* Milestone markers */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, padding: '0 2px' }}>
                      {PERCENT_MILESTONES.map(m => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => handlePercentChange(m)}
                          style={{
                            background: formData.discountPercent === m ? 'var(--accent)' : 'var(--bg-card-hover)',
                            color: formData.discountPercent === m ? 'white' : 'var(--text-muted)',
                            border: '1px solid',
                            borderColor: formData.discountPercent === m ? 'var(--accent)' : 'var(--border)',
                            borderRadius: 6,
                            padding: '3px 8px',
                            fontSize: 11,
                            fontWeight: 700,
                            cursor: 'pointer',
                            transition: 'all 0.15s ease',
                            fontFamily: 'var(--font-mono)'
                          }}
                        >
                          {m}%
                        </button>
                      ))}
                    </div>
                  </div>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    background: 'var(--accent-light)',
                    borderRadius: 10,
                    padding: '8px 4px 8px 12px',
                    minWidth: 90
                  }}>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={formData.discountPercent}
                      onChange={e => handlePercentChange(e.target.value)}
                      style={{
                        width: 44,
                        border: 'none',
                        background: 'transparent',
                        fontSize: 20,
                        fontWeight: 800,
                        color: 'var(--accent)',
                        textAlign: 'center',
                        outline: 'none',
                        fontFamily: 'var(--font-mono)'
                      }}
                    />
                    <span style={{ fontSize: 18, fontWeight: 800, color: 'var(--accent)' }}>%</span>
                  </div>
                </div>
                {formErrors.discountPercent && <span className="error-text text-danger" style={{ fontSize: 12, marginTop: 4, display: 'block' }}>{formErrors.discountPercent}</span>}
              </div>

              <div className="form-row" style={{ gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div className="form-group">
                  <label className="form-label">Giảm tối đa (VND)</label>
                  <input
                    type="number"
                    className="form-control"
                    placeholder="Không giới hạn nếu bỏ trống"
                    value={formData.maxDiscount}
                    onChange={e => setFormData(prev => ({ ...prev, maxDiscount: e.target.value }))}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Đơn tối thiểu (VND)</label>
                  <input
                    type="number"
                    className="form-control"
                    placeholder="0 = Không yêu cầu"
                    value={formData.minOrderValue}
                    onChange={e => setFormData(prev => ({ ...prev, minOrderValue: e.target.value }))}
                  />
                </div>
              </div>

              <div className="form-row" style={{ gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div className="form-group">
                  <label className="form-label">Mã Voucher <span>*</span></label>
                  <input
                    type="text"
                    className={`form-control ${formErrors.code ? 'is-invalid' : ''}`}
                    value={formData.code}
                    onChange={e => setFormData(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                    placeholder="Tự sinh hoặc nhập thủ công"
                    style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, letterSpacing: 1 }}
                  />
                  {formErrors.code && <span className="error-text text-danger" style={{ fontSize: 12, marginTop: 4, display: 'block' }}>{formErrors.code}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Hạn sử dụng <span>*</span></label>
                  <input
                    type="date"
                    className={`form-control ${formErrors.expiryDate ? 'is-invalid' : ''}`}
                    value={formData.expiryDate}
                    onChange={e => setFormData(prev => ({ ...prev, expiryDate: e.target.value }))}
                  />
                  {formErrors.expiryDate && <span className="error-text text-danger" style={{ fontSize: 12, marginTop: 4, display: 'block' }}>{formErrors.expiryDate}</span>}
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Ghi chú</label>
                <textarea
                  className="form-control"
                  rows="2"
                  placeholder="Ghi chú nội bộ (không hiển thị cho khách)"
                  value={formData.note}
                  onChange={e => setFormData(prev => ({ ...prev, note: e.target.value }))}
                />
              </div>

              {/* Preview */}
              {formData.customerId && (
                <div style={{
                  marginTop: 20,
                  padding: 16,
                  background: 'linear-gradient(135deg, #fff7ed, #fef3c7)',
                  borderRadius: 12,
                  border: '1px dashed var(--accent)'
                }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 1 }}>Xem trước voucher</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{
                      fontSize: 32,
                      fontWeight: 900,
                      color: 'var(--accent)',
                      fontFamily: 'var(--font-mono)',
                      lineHeight: 1
                    }}>
                      -{formData.discountPercent}%
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'var(--font-mono)', letterSpacing: 1, color: 'var(--text-primary)' }}>
                        {formData.code || '...'}
                      </div>
                      <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>
                        Dành cho <strong>{formData.customerName}</strong>
                        {formData.maxDiscount && <> · Tối đa {formatCurrency(Number(formData.maxDiscount))}</>}
                        {formData.minOrderValue && Number(formData.minOrderValue) > 0 && <> · Đơn từ {formatCurrency(Number(formData.minOrderValue))}</>}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="form-actions" style={{ marginTop: 20 }}>
                <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Hủy</button>
                <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                  {saving ? 'Đang tạo...' : 'Tạo Voucher'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteId && (
        <ConfirmDialog
          isOpen={true}
          title="Xóa voucher"
          message="Bạn có chắc muốn xóa voucher này? Hành động không thể hoàn tác."
          onConfirm={handleDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}
