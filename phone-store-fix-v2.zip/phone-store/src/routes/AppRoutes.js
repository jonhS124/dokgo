import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../utils/AuthContext';

// Pages
import LoginPage from '../pages/LoginPage';
import RegisterPage from '../pages/RegisterPage';
import DashboardPage from '../pages/DashboardPage';
import ProductsPage from '../pages/ProductsPage';
import AdminProductsPage from '../pages/AdminProductsPage';
import VouchersPage from '../pages/VouchersPage';
import ProductDetailsPage from '../pages/ProductDetailsPage';
import OrdersPage from '../pages/OrdersPage';
import CustomersPage from '../pages/CustomersPage';
import CartPage from '../pages/CartPage';
import CheckoutPage from '../pages/CheckoutPage';
import ProfileLayout from '../components/Layout/ProfileLayout';
import ProfilePage from '../pages/customer/ProfilePage';
import MyOrdersPage from '../pages/customer/MyOrdersPage';
import ReceiptsPage from '../pages/customer/ReceiptsPage';
import PurchaseHistoryPage from '../pages/customer/PurchaseHistoryPage';

// Layout
import MainLayout from '../components/Layout/MainLayout';

/**
 * ProtectedRoute: Chặn truy cập nếu chưa đăng nhập
 */
function ProtectedRoute({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

/**
 * AdminRoute: Chỉ admin mới được vào (User thường sẽ bị đẩy về products)
 */
function AdminRoute({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'admin') return <Navigate to="/products" replace />;
  return children;
}

/**
 * AppRoutes: Cấu hình tất cả routes
 * - Trang sản phẩm là trang mặc định (public)
 * - Dashboard, Orders, Customers cần đăng nhập
 */
export default function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* App routes với Layout */}
      <Route path="/" element={<MainLayout />}>
        {/* Mặc định chuyển đến trang sản phẩm */}
        <Route index element={<Navigate to="/products" replace />} />

        {/* Sản phẩm, Giỏ hàng - public, ai cũng xem được */}
        <Route path="products" element={<ProductsPage />} />
        <Route path="products/:id" element={<ProductDetailsPage />} />
        <Route path="cart" element={<CartPage />} />
        <Route path="checkout" element={<CheckoutPage />} />

        {/* Các trang cần đăng nhập & quyền Admin */}
        <Route path="dashboard" element={
          <AdminRoute><DashboardPage /></AdminRoute>
        } />
        <Route path="orders" element={
          <AdminRoute><OrdersPage /></AdminRoute>
        } />
        <Route path="customers" element={
          <AdminRoute><CustomersPage /></AdminRoute>
        } />
        <Route path="manage-products" element={
          <AdminRoute><AdminProductsPage /></AdminRoute>
        } />
        <Route path="vouchers" element={
          <AdminRoute><VouchersPage /></AdminRoute>
        } />

        {/* Trang Khách Hàng (User Profile) */}
        <Route element={<ProtectedRoute><ProfileLayout /></ProtectedRoute>}>
          <Route path="profile" element={<ProfilePage />} />
          <Route path="my-orders" element={<MyOrdersPage />} />
          <Route path="receipts" element={<ReceiptsPage />} />
          <Route path="purchase-history" element={<PurchaseHistoryPage />} />
          <Route path="repair-history" element={<Navigate to="/profile" replace />} />
          <Route path="address-book" element={<Navigate to="/profile" replace />} />
          <Route path="notifications" element={<Navigate to="/profile" replace />} />
        </Route>
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/products" replace />} />
    </Routes>
  );
}
