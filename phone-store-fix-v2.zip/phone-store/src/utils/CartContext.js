import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

// Lấy key localStorage theo user ID (phân biệt giỏ hàng từng user)
function getCartKey(userId) {
  return userId ? `phone_store_cart_${userId}` : 'phone_store_cart_guest';
}

export function CartProvider({ children }) {
  const { user } = useAuth();
  const userId = user?.id || null;

  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem(getCartKey(userId));
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Khi user thay đổi (login/logout/switch) → load đúng giỏ hàng của user đó
  useEffect(() => {
    try {
      const saved = localStorage.getItem(getCartKey(userId));
      setCart(saved ? JSON.parse(saved) : []);
    } catch {
      setCart([]);
    }
  }, [userId]);

  // Lưu cart vào localStorage mỗi khi thay đổi
  useEffect(() => {
    localStorage.setItem(getCartKey(userId), JSON.stringify(cart));
  }, [cart, userId]);

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.quantity) {
          toast.error(`Chỉ còn ${product.quantity} sản phẩm trong kho!`);
          return prev;
        }
        toast.success(`Đã tăng số lượng ${product.name} trong giỏ`);
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      toast.success(`Đã thêm ${product.name} vào giỏ hàng`);
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    toast.success('Đã xoá sản phẩm khỏi giỏ hàng');
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity < 1) return;
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        if (newQuantity > item.product.quantity) {
          toast.error(`Chỉ còn ${item.product.quantity} sản phẩm trong kho!`);
          return item;
        }
        return { ...item, quantity: newQuantity };
      }
      return item;
    }));
  };

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const cartTotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);

  return (
    <CartContext.Provider value={{
      cart,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartTotal,
      cartCount
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart phải được dùng trong CartProvider');
  return ctx;
}
