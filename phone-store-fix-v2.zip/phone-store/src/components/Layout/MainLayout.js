import React, { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from './Header';
import TopMenu from './TopMenu';
import Footer from './Footer';

export default function MainLayout() {
  const location = useLocation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  // Hide TopMenu on Cart, Admin, and Profile pages
  const hideTopMenuPaths = ['/cart', '/checkout', '/dashboard', '/orders', '/customers', '/manage-products', '/vouchers', '/profile', '/my-orders', '/receipts', '/purchase-history'];
  const showTopMenu = !hideTopMenuPaths.some(path => location.pathname.startsWith(path)) && !location.pathname.match(/^\/products\/.+/);

  return (
    <div className="app-layout">
      <Header />
      {showTopMenu && <TopMenu />}
      <div className="main-content">
        <main className="page-body animate-in">
          <Outlet />
        </main>
      </div>
      <Footer />
    </div>
  );
}
