import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../utils/AuthContext';
import { useCart } from '../../utils/CartContext';
import toast from 'react-hot-toast';
import './Header.css';

export default function Header() {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (keyword.trim()) {
      navigate(`/products?search=${keyword}`);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Đã đăng xuất!');
    navigate('/');
  };

  return (
    <header className="header">
      <div className="header-container">
        {/* Logo */}
        <Link to="/" className="header-logo">
          <div className="logo-icon">M</div>
          <div className="logo-text">
            <span className="logo-mobile">Mobile</span>
            <span className="logo-city">City</span>
          </div>
        </Link>

        {/* Search Box */}
        <form className="header-search" onSubmit={handleSearch}>
          <input 
            type="text" 
            placeholder="Bạn cần tìm gì?" 
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
          <button type="submit" className="search-btn">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </button>
        </form>

        {/* Action icons */}
        <div className="header-actions">
          <a href="tel:0834253689" className="header-action-item hotline-item">
            <span className="action-icon"></span>
            <div className="action-text">
              <span>Gọi mua hàng</span>
              <strong>083.425.3689</strong>
            </div>
          </a>

          <Link to="/cart" className="header-action-item cart-item">
            <div className="cart-icon-wrapper">
              <span className="action-icon iconnewglobal-whitecart">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="9" cy="21" r="1"></circle>
                  <circle cx="20" cy="21" r="1"></circle>
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
              </span>
              {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
            </div>
            <div className="action-text">
              <span>Giỏ hàng</span>
              <strong>của bạn</strong>
            </div>
          </Link>

          {user ? (
            <div className="header-action-item user-item-dropdown">
              <span className="action-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </span>
              <div className="action-text">
                <span>Xin chào,</span>
                <strong>{user.name}</strong>
              </div>
              
              <div className="dropdown-menu custom-dropdown">
                {user.role === 'admin' ? (
                  <>
                    <Link to="/dashboard" className="dropdown-item" style={{ color: 'var(--accent)', fontWeight: 600 }}>🛠 Admin Dashboard</Link>
                    <Link to="/orders" className="dropdown-item">Quản lý Đơn hàng</Link>
                    <Link to="/customers" className="dropdown-item">Quản lý Khách hàng</Link>
                    <Link to="/manage-products" className="dropdown-item">Quản lý Sản phẩm</Link>
                    <Link to="/vouchers" className="dropdown-item">Mã giảm giá</Link>
                  </>
                ) : (
                  <>
                    <Link to="/profile" className="dropdown-item">Thông tin tài khoản</Link>
                    <Link to="/my-orders" className="dropdown-item">Đơn đặt hàng</Link>
                    <Link to="/purchase-history" className="dropdown-item">Lịch sử mua hàng</Link>
                    <Link to="/receipts" className="dropdown-item">Phiếu nhận máy</Link>
                  </>
                )}
                
                <div className="dropdown-divider"></div>
                <button onClick={handleLogout} className="dropdown-item">Đăng xuất</button>
              </div>
            </div>
          ) : (
            <Link to="/login" className="header-action-item">
              <span className="action-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </span>
              <div className="action-text">
                <span>Đăng nhập</span>
                <strong>Tài khoản</strong>
              </div>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
