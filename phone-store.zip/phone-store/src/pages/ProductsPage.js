import React, { useEffect, useState, useCallback } from 'react';
import { productsApi } from '../services/api';
import { formatCurrency } from '../utils/format';
import Loading from '../components/Loading';
import Pagination from '../components/Pagination';
import toast from 'react-hot-toast';
import { useCart } from '../utils/CartContext';
import { Link, useSearchParams } from 'react-router-dom';

const BRANDS = ['Tất cả', 'Apple', 'Samsung', 'Xiaomi', 'OPPO', 'Vivo', 'Realme', 'Nokia', 'Khác'];
const PAGE_SIZE = 8;

// ===== Main Page =====
export default function ProductsPage() {
  const { addToCart } = useCart();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const [searchParams] = useSearchParams();
  const search = searchParams.get('search') || '';
  const brandFilter = searchParams.get('brand') || 'Tất cả';

  const [sortBy, setSortBy] = useState(''); // 'price_asc' | 'price_desc' | 'name'
  const [page, setPage] = useState(1);

  // Fetch danh sách sản phẩm
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await productsApi.getAll();
      setProducts(res.data);
    } catch {
      toast.error('Không thể tải danh sách sản phẩm');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  // Reset page khi filter thay đổi
  useEffect(() => { setPage(1); }, [search, brandFilter, sortBy]);

  // Lọc & sắp xếp
  let filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.brand.toLowerCase().includes(search.toLowerCase());
    const matchBrand = brandFilter === 'Tất cả' || p.brand === brandFilter;
    return matchSearch && matchBrand;
  });

  if (sortBy === 'price_asc') filtered.sort((a, b) => a.price - b.price);
  else if (sortBy === 'price_desc') filtered.sort((a, b) => b.price - a.price);
  else if (sortBy === 'name') filtered.sort((a, b) => a.name.localeCompare(b.name));

  // Phân trang
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  if (loading) return <Loading text="Đang tải sản phẩm..." />;

  return (
    <div>
      {/* MobileCity Banner (Only on Home) */}
      {!search && brandFilter === 'Tất cả' && (
        <div style={{ marginBottom: 24, borderRadius: 12, overflow: 'hidden' }}>
          <img 
            src="https://cdn.hoanghamobile.com/i/home/Uploads/2023/10/24/iphone-15-pro-max-banner.jpg" 
            alt="Promotion Banner" 
            style={{ width: '100%', height: 'auto', display: 'block' }} 
            onError={(e) => { e.target.style.display = 'none'; }} 
          />
        </div>
      )}

      {/* Toolbar */}
      <div className="toolbar" style={{ justifyContent: 'space-between', borderBottom: '1px solid var(--border)', paddingBottom: 16 }}>
        <h2 style={{ fontSize: 20, margin: 0, fontWeight: 700 }}>
          {search 
            ? `Kết quả tìm kiếm cho "${search}"` 
            : brandFilter !== 'Tất cả' 
              ? `Điện thoại ${brandFilter}` 
              : 'Tất cả sản phẩm'
          }
        </h2>
        <select
          className="filter-select"
          value={sortBy}
          onChange={e => setSortBy(e.target.value)}
        >
          <option value="">Sắp xếp mặc định</option>
          <option value="price_asc">Giá thấp → cao</option>
          <option value="price_desc">Giá cao → thấp</option>
          <option value="name">Tên A → Z</option>
        </select>
      </div>

      {/* Product Grid */}
      <div className="product-list-container">
        {filtered.length === 0 ? (
          <div className="card">
            <div className="empty-state">
              <h3>Không tìm thấy sản phẩm</h3>
              <p>Thử thay đổi bộ lọc hoặc từ khoá tìm kiếm</p>
            </div>
          </div>
        ) : (
          <>
            <div className="product-grid">
              {paginated.map((product) => (
                <div key={product.id} className="product-card">
                  {/* Image */}
                  <div className="product-card-img-wrapper" style={{ position: 'relative' }}>
                    <Link to={`/products/${product.id}`} style={{ display: 'block', width: '100%', height: '100%' }}>
                      {product.image ? (
                        <img
                          src={product.image}
                          alt={product.name}
                          className="product-card-img"
                          onError={(e) => {
                            e.target.style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="product-img-placeholder" style={{ width: '100%', height: '100%', border: 'none' }}></div>
                      )}
                    </Link>
                  </div>

                  {/* Body */}
                  <div className="product-card-body">
                    <div className="product-card-brand">{product.brand}</div>
                    <Link to={`/products/${product.id}`} className="product-card-title hover-accent" style={{ color: 'inherit', textDecoration: 'none' }}>
                      {product.name}
                    </Link>

                    <div className="product-card-price">
                      {formatCurrency(product.price)}
                    </div>

                    <button
                      className="btn btn-primary"
                      style={{ marginTop: '12px', width: '100%', justifyContent: 'center', fontSize: '13px', padding: '8px' }}
                      onClick={() => addToCart(product)}
                      disabled={product.quantity === 0}
                    >
                      {product.quantity === 0 ? 'Hết hàng' : 'Thêm vào giỏ'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="card" style={{ marginTop: 24 }}>
              <Pagination
                page={page}
                totalPages={totalPages}
                total={filtered.length}
                pageSize={PAGE_SIZE}
                onPageChange={setPage}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
