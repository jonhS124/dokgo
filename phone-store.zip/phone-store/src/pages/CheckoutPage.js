import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useAuth } from '../utils/AuthContext';
import { useCart } from '../utils/CartContext';
import './CheckoutPage.css'; // Sẽ tạo file CSS sau

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

export default function CheckoutPage() {
  const { cart, clearCart, cartTotal } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect to cart if empty
  useEffect(() => {
    if (cart.length === 0) {
      navigate('/cart');
    }
  }, [cart, navigate]);

  const [loading, setLoading] = useState(false);
  
  // Thông tin khách hàng
  const [customer, setCustomer] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    address: user?.address || '',
    province: '', // Hà Nội = 20k, TP.HCM = 20k, Khác = 40k
  });

  // Tùy chọn giao hàng & thanh toán
  const [shippingMethod, setShippingMethod] = useState('standard'); // standard | express (+20k)
  const [paymentMethod, setPaymentMethod] = useState('cod'); // cod | bank | wallet
  const [bankInfo, setBankInfo] = useState({ card: '', exp: '', cvv: '' });
  
  // Voucher
  const [voucherCode, setVoucherCode] = useState('');
  const [discount, setDiscount] = useState(0); // Số tiền giảm

  // Validation
  const [errors, setErrors] = useState({});

  // Tính toán phí giao hàng
  const getBaseShippingFee = () => {
    if (!customer.province) return 0;
    if (['Hà Nội', 'TP.HCM'.toLowerCase(), 'hồ chí minh'].some(p => customer.province.toLowerCase().includes(p))) {
      return 20000;
    }
    return 40000; // Tỉnh khác
  };

  const shippingFee = getBaseShippingFee() + (shippingMethod === 'express' ? 20000 : 0);
  const finalTotal = cartTotal + shippingFee - discount;

  const handleApplyVoucher = () => {
    const code = voucherCode.trim().toUpperCase();
    if (code === 'SALE10') {
      setDiscount(cartTotal * 0.1);
      toast.success('Áp dụng mã giảm 10% thành công!');
    } else if (code === 'FREESHIP') {
      setDiscount(shippingFee);
      toast.success('Áp dụng mã Freeship thành công!');
    } else {
      setDiscount(0);
      toast.error('Mã giảm giá không hợp lệ!');
    }
  };

  const validateForm = () => {
    let newErrors = {};
    if (!customer.name.trim()) newErrors.name = 'Vui lòng nhập họ tên';
    
    const phoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
    if (!customer.phone.trim()) newErrors.phone = 'Vui lòng nhập số điện thoại';
    else if (!phoneRegex.test(customer.phone)) newErrors.phone = 'Số điện thoại không hợp lệ';

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!customer.email.trim()) newErrors.email = 'Vui lòng nhập email';
    else if (!emailRegex.test(customer.email)) newErrors.email = 'Email không hợp lệ';

    if (!customer.province.trim()) newErrors.province = 'Vui lòng chọn hoặc nhập Tỉnh/Thành phố';
    if (!customer.address.trim()) newErrors.address = 'Vui lòng nhập địa chỉ cụ thể';

    if (paymentMethod === 'bank') {
      if (!bankInfo.card.trim()) newErrors.card = 'Vui lòng nhập số thẻ';
      if (!bankInfo.exp.trim()) newErrors.exp = 'Vui lòng nhập ngày hết hạn';
      if (!bankInfo.cvv.trim()) newErrors.cvv = 'Vui lòng nhập CVV';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePlaceOrder = async () => {
    if (!validateForm()) {
      toast.error('Vui lòng kiểm tra lại thông tin!');
      return;
    }

    setLoading(true);
    try {
      const orderData = {
        customerId: user?.id || 'guest_' + Date.now(),
        customerName: customer.name,
        shippingDetails: {
          phone: customer.phone,
          email: customer.email,
          address: customer.address,
          province: customer.province,
          method: shippingMethod
        },
        payment: {
          method: paymentMethod,
          status: paymentMethod === 'cod' ? 'Pending' : 'Paid (Mock)'
        },
        items: cart.map(item => ({
          productId: item.product.id,
          productName: item.product.name,
          price: item.product.price,
          quantity: item.quantity
        })),
        subtotal: cartTotal,
        shippingFee: shippingFee,
        discount: discount,
        total: finalTotal,
        status: 'Pending',
        createdAt: new Date().toISOString().split('T')[0]
      };

      await axios.post(`${API_URL}/orders`, orderData);
      
      // Cập nhật lại số lượng tồn kho (quantity) cho từng sản phẩm
      for (const item of cart) {
        try {
          const productRes = await axios.get(`${API_URL}/products/${item.product.id}`);
          const currentProduct = productRes.data;
          const newQuantity = Math.max(0, currentProduct.quantity - item.quantity);
          
          await axios.patch(`${API_URL}/products/${item.product.id}`, {
            quantity: newQuantity
          });
        } catch (error) {
          console.error(`Lỗi cập nhật số lượng sản phẩm ${item.product.id}:`, error);
        }
      }
      
      toast.success('Đặt hàng thành công! Cảm ơn bạn đã mua sắm.');
      clearCart();
      navigate('/products');
    } catch (err) {
      toast.error('Có lỗi xảy ra khi đặt hàng');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  if (cart.length === 0) return null; // Will redirect in useEffect

  return (
    <div className="page-body checkout-page animate-in">
      <div className="page-header">
        <h1 className="page-title">Thanh toán</h1>
        <p className="page-subtitle">Hoàn tất thông tin để đặt hàng</p>
      </div>

      <div className="checkout-container form-row" style={{ gridTemplateColumns: '1.5fr 1fr', gap: '32px', alignItems: 'start' }}>
        
        {/* LÊFT COLUMN: Form */}
        <div className="checkout-forms" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* S1. Thông tin giao hàng */}
          <div className="card">
            <div className="card-header"><h3 style={{ margin: 0 }}>1. Thông tin người nhận</h3></div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">Họ và tên *</label>
                <input type="text" className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={customer.name} onChange={e => setCustomer({...customer, name: e.target.value})} placeholder="Nhập họ tên đầy đủ" />
                {errors.name && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4, display: 'block'}}>{errors.name}</span>}
              </div>

              <div className="form-row" style={{ gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="form-group">
                  <label className="form-label">Số điện thoại *</label>
                  <input type="tel" className={`form-control ${errors.phone ? 'is-invalid' : ''}`} value={customer.phone} onChange={e => setCustomer({...customer, phone: e.target.value})} placeholder="09xx..." />
                  {errors.phone && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4, display: 'block'}}>{errors.phone}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Email *</label>
                  <input type="email" className={`form-control ${errors.email ? 'is-invalid' : ''}`} value={customer.email} onChange={e => setCustomer({...customer, email: e.target.value})} placeholder="email@example.com" />
                  {errors.email && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4, display: 'block'}}>{errors.email}</span>}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Tỉnh / Thành phố *</label>
                <select className={`form-control ${errors.province ? 'is-invalid' : ''}`} value={customer.province} onChange={e => setCustomer({...customer, province: e.target.value})}>
                  <option value="">-- Chọn Tỉnh/Thành phố --</option>
                  <option value="Hà Nội">Hà Nội</option>
                  <option value="TP.HCM">TP.HCM</option>
                  <option value="Đà Nẵng">Đà Nẵng</option>
                  <option value="Khác">Tỉnh thành khác</option>
                </select>
                {errors.province && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4, display: 'block'}}>{errors.province}</span>}
              </div>

              <div className="form-group" style={{ marginBottom: 0 }}>
                <label className="form-label">Địa chỉ cụ thể *</label>
                <input type="text" className={`form-control ${errors.address ? 'is-invalid' : ''}`} value={customer.address} onChange={e => setCustomer({...customer, address: e.target.value})} placeholder="Số nhà, tên đường, phường/xã..." />
                {errors.address && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4, display: 'block'}}>{errors.address}</span>}
              </div>
            </div>
          </div>

          {/* S2. Vận chuyển */}
          <div className="card">
            <div className="card-header"><h3 style={{ margin: 0 }}>2. Phương thức vận chuyển</h3></div>
            <div className="card-body">
              {!customer.province ? (
                <div className="alert alert-info" style={{background: '#e0f2fe', color: '#0369a1', padding: '12px 16px', borderRadius: 8}}>Vui lòng chọn Tỉnh/Thành phố ở trên để xem phí vận chuyển.</div>
              ) : (
                <div className="radio-group" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <label className={`radio-card ${shippingMethod === 'standard' ? 'selected' : ''}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 16, border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', background: shippingMethod === 'standard' ? '#f0fdf4' : '#fff', borderColor: shippingMethod === 'standard' ? 'var(--success)' : 'var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <input type="radio" name="shipping" checked={shippingMethod === 'standard'} onChange={() => setShippingMethod('standard')} style={{ transform: 'scale(1.2)' }} />
                      <div>
                        <div style={{ fontWeight: 600 }}>Giao hàng tiêu chuẩn</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Nhận hàng trong 3-5 ngày làm việc</div>
                      </div>
                    </div>
                    <div style={{ fontWeight: 600 }}>{formatCurrency(getBaseShippingFee())}</div>
                  </label>
                  
                  <label className={`radio-card ${shippingMethod === 'express' ? 'selected' : ''}`} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 16, border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', background: shippingMethod === 'express' ? '#f0fdf4' : '#fff', borderColor: shippingMethod === 'express' ? 'var(--success)' : 'var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <input type="radio" name="shipping" checked={shippingMethod === 'express'} onChange={() => setShippingMethod('express')} style={{ transform: 'scale(1.2)' }} />
                      <div>
                        <div style={{ fontWeight: 600 }}>Giao hàng nhanh</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Nhận hàng trong 1-2 ngày làm việc (Cộng thêm 20k)</div>
                      </div>
                    </div>
                    <div style={{ fontWeight: 600 }}>{formatCurrency(getBaseShippingFee() + 20000)}</div>
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* S3. Thanh toán */}
          <div className="card">
            <div className="card-header"><h3 style={{ margin: 0 }}>3. Phương thức thanh toán</h3></div>
            <div className="card-body">
               <div className="radio-group" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'center', padding: 16, border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', background: paymentMethod === 'cod' ? '#fbf8ff' : '#fff', borderColor: paymentMethod === 'cod' ? 'var(--accent)' : 'var(--border)' }}>
                    <input type="radio" name="payment" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} style={{ transform: 'scale(1.2)', marginRight: 12 }} />
                    <span style={{ fontWeight: 600 }}>Thanh toán khi nhận hàng (COD)</span>
                  </label>

                  <label style={{ display: 'flex', alignItems: 'center', padding: 16, border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', background: paymentMethod === 'bank' ? '#fbf8ff' : '#fff', borderColor: paymentMethod === 'bank' ? 'var(--accent)' : 'var(--border)' }}>
                    <input type="radio" name="payment" checked={paymentMethod === 'bank'} onChange={() => setPaymentMethod('bank')} style={{ transform: 'scale(1.2)', marginRight: 12 }} />
                    <span style={{ fontWeight: 600 }}>Thẻ tín dụng / Thẻ ghi nợ (Visa/Mastercard)</span>
                  </label>
                  
                  {paymentMethod === 'bank' && (
                    <div style={{ padding: 16, background: '#f8f9fa', borderRadius: 8, marginTop: -4, border: '1px solid var(--border)' }}>
                      <div className="form-group">
                        <label className="form-label">Số thẻ</label>
                        <input type="text" className={`form-control ${errors.card ? 'is-invalid' : ''}`} placeholder="0000 0000 0000 0000" value={bankInfo.card} onChange={e => setBankInfo({...bankInfo, card: e.target.value})} />
                        {errors.card && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4}}>{errors.card}</span>}
                      </div>
                      <div className="form-row" style={{ gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 0 }}>
                        <div className="form-group" style={{ marginBottom: 0 }}>
                          <label className="form-label">Ngày hết hạn</label>
                          <input type="text" className={`form-control ${errors.exp ? 'is-invalid' : ''}`} placeholder="MM/YY" value={bankInfo.exp} onChange={e => setBankInfo({...bankInfo, exp: e.target.value})} />
                          {errors.exp && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4}}>{errors.exp}</span>}
                        </div>
                        <div className="form-group" style={{ marginBottom: 0 }}>
                          <label className="form-label">CVV</label>
                          <input type="password" maxLength={3} className={`form-control ${errors.cvv ? 'is-invalid' : ''}`} placeholder="123" value={bankInfo.cvv} onChange={e => setBankInfo({...bankInfo, cvv: e.target.value})} />
                          {errors.cvv && <span className="error-text text-danger" style={{fontSize: 12, marginTop: 4}}>{errors.cvv}</span>}
                        </div>
                      </div>
                    </div>
                  )}

                  <label style={{ display: 'flex', alignItems: 'center', padding: 16, border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', background: paymentMethod === 'wallet' ? '#fbf8ff' : '#fff', borderColor: paymentMethod === 'wallet' ? 'var(--accent)' : 'var(--border)' }}>
                    <input type="radio" name="payment" checked={paymentMethod === 'wallet'} onChange={() => setPaymentMethod('wallet')} style={{ transform: 'scale(1.2)', marginRight: 12 }} />
                    <span style={{ fontWeight: 600 }}>Ví điện tử (MoMo, ZaloPay, VNPAY)</span>
                  </label>
               </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Summary */}
        <div className="checkout-summary card sticky" style={{ position: 'sticky', top: '100px', maxHeight: 'calc(100vh - 120px)', overflowY: 'auto' }}>
          <div className="card-header"><h3 style={{ margin: 0 }}>Đơn hàng ({cart.length} sản phẩm)</h3></div>
          <div className="card-body">
            
            <div className="cart-items-preview" style={{ maxHeight: 300, overflowY: 'auto', marginBottom: 20, borderBottom: '1px solid var(--border)' }}>
              {cart.map(item => (
                <div key={item.product.id} style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
                  {item.product.image ? (
                    <img src={item.product.image} alt={item.product.name} style={{ width: 60, height: 60, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }} />
                  ) : (
                    <div style={{ width: 60, height: 60, background: '#eee', borderRadius: 8 }}></div>
                  )}
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{item.product.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                      <span>SL: {item.quantity}</span>
                      <strong style={{ color: 'var(--text-primary)' }}>{formatCurrency(item.product.price * item.quantity)}</strong>
                    </div>
                  </div>
                </div>
              ))}
              <div style={{ marginBottom: 16 }}>
                 <button className="btn btn-outline" style={{width: '100%', fontSize: 13, padding: 8}} onClick={() => navigate('/cart')}>Trở về Giỏ hàng để sửa</button>
              </div>
            </div>

            <div className="voucher-section" style={{ marginBottom: 20, paddingBottom: 20, borderBottom: '1px solid var(--border)' }}>
              <label className="form-label">Mã giảm giá</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" className="form-control" placeholder="SALE10, FREESHIP..." value={voucherCode} onChange={e => setVoucherCode(e.target.value)} />
                <button className="btn btn-outline" onClick={handleApplyVoucher}>Áp dụng</button>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <span className="text-secondary">Tạm tính:</span>
              <span style={{ fontWeight: 500 }}>{formatCurrency(cartTotal)}</span>
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <span className="text-secondary">Phí vận chuyển:</span>
              <span style={{ fontWeight: 500 }}>{formatCurrency(shippingFee)}</span>
            </div>

            {discount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                <span className="text-secondary">Giảm giá:</span>
                <span style={{ fontWeight: 600, color: 'var(--danger)' }}>-{formatCurrency(discount)}</span>
              </div>
            )}
            
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24, marginTop: 16, paddingTop: 16, borderTop: '2px dashed var(--border)', alignItems: 'center' }}>
              <span style={{ fontSize: 16, fontWeight: 700 }}>Tổng thanh toán:</span>
              <span className="price" style={{ fontSize: 24, color: 'var(--accent)' }}>{formatCurrency(Math.max(0, finalTotal))}</span>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', justifyContent: 'center', padding: '16px', fontSize: 16, fontWeight: 700, borderRadius: 8 }}
              onClick={handlePlaceOrder}
              disabled={loading}
            >
              {loading ? 'Đang xử lý...' : 'THANH TOÁN ĐƠN HÀNG'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
