import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, PieChart, Pie, Cell, Legend
} from 'recharts';
import { productsApi, ordersApi, customersApi } from '../services/api';
import { formatCurrency, formatDate, getOrderStatusBadge } from '../utils/format';
import Loading from '../components/Loading';

// Tính doanh thu thực tế theo tháng từ danh sách đơn hàng
function getMonthlyRevenue(orders) {
  const now = new Date();
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({
      year: d.getFullYear(),
      month: d.getMonth(), // 0-indexed
      label: `T${d.getMonth() + 1}/${d.getFullYear()}`,
    });
  }

  return months.map(m => {
    const revenue = orders
      .filter(o => {
        if (o.status !== 'Completed') return false;
        const od = new Date(o.createdAt);
        return od.getFullYear() === m.year && od.getMonth() === m.month;
      })
      .reduce((sum, o) => sum + (o.total || 0), 0);
    return { month: m.label, revenue };
  });
}

const STATUS_COLORS = {
  Completed: '#22c55e',
  Pending: '#f59e0b',
  Cancelled: '#ef4444',
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'var(--bg-card)', border: '1px solid var(--border)',
      borderRadius: 8, padding: '10px 14px', fontSize: 13
    }}>
      <div style={{ color: 'var(--text-muted)', marginBottom: 4 }}>{label}</div>
      <div style={{ color: 'var(--success)', fontWeight: 700 }}>
        {formatCurrency(payload[0].value)}
      </div>
    </div>
  );
};

export default function DashboardPage() {
  const navigate = useNavigate();
  const [data, setData] = useState({ products: [], orders: [], customers: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [p, o, c] = await Promise.all([
          productsApi.getAll(),
          ordersApi.getAll(),
          customersApi.getAll(),
        ]);
        setData({
          products: p.data,
          orders: o.data,
          customers: c.data,
        });
      } catch (err) {
        console.error('Dashboard fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  if (loading) return <Loading text="Đang tải dashboard..." />;

  // Tính toán thống kê
  const totalRevenue = data.orders
    .filter(o => o.status === 'Completed')
    .reduce((sum, o) => sum + o.total, 0);

  const pendingOrders = data.orders.filter(o => o.status === 'Pending').length;
  const completedOrders = data.orders.filter(o => o.status === 'Completed').length;
  const cancelledOrders = data.orders.filter(o => o.status === 'Cancelled').length;

  const lowStockProducts = data.products.filter(p => p.quantity < 15);

  // Dữ liệu pie chart trạng thái đơn hàng
  const statusData = [
    { name: 'Hoàn thành', value: completedOrders, color: '#22c55e' },
    { name: 'Chờ xử lý', value: pendingOrders, color: '#f59e0b' },
    { name: 'Đã huỷ', value: cancelledOrders, color: '#ef4444' },
  ].filter(d => d.value > 0);

  // Doanh thu thực tế theo tháng (6 tháng gần nhất)
  const revenueData = getMonthlyRevenue(data.orders);

  // Sản phẩm bán nhiều nhất (giả lập từ orders)
  const productSales = {};
  data.orders.forEach(order => {
    if (order.status === 'Cancelled') return;
    order.items?.forEach(item => {
      productSales[item.productName] = (productSales[item.productName] || 0) + item.quantity;
    });
  });
  const topProducts = Object.entries(productSales)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, qty]) => ({ name: name.length > 20 ? name.slice(0, 18) + '…' : name, qty }));

  // 5 đơn hàng gần nhất
  const recentOrders = [...data.orders]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Dashboard</div>
          <div className="page-subtitle">Tổng quan hoạt động cửa hàng</div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card blue" onClick={() => navigate('/products')} style={{ cursor: 'pointer' }}>
          <div className="stat-icon blue"></div>
          <div className="stat-value">{data.products.length}</div>
          <div className="stat-label">Tổng sản phẩm</div>
          <div className="stat-change up">{lowStockProducts.length} sắp hết hàng</div>
        </div>

        <div className="stat-card green" onClick={() => navigate('/orders')} style={{ cursor: 'pointer' }}>
          <div className="stat-icon green"></div>
          <div className="stat-value">{data.orders.length}</div>
          <div className="stat-label">Tổng đơn hàng</div>
          <div className="stat-change up">{pendingOrders} đang chờ xử lý</div>
        </div>

        <div className="stat-card purple" onClick={() => navigate('/customers')} style={{ cursor: 'pointer' }}>
          <div className="stat-icon purple"></div>
          <div className="stat-value">{data.customers.length}</div>
          <div className="stat-label">Khách hàng</div>
          <div className="stat-change up">Tháng này</div>
        </div>

        <div className="stat-card orange">
          <div className="stat-icon orange"></div>
          <div className="stat-value" style={{ fontSize: 20 }}>{formatCurrency(totalRevenue)}</div>
          <div className="stat-label">Doanh thu ({completedOrders} đơn)</div>
          <div className="stat-change up">Từ đơn hoàn thành</div>
        </div>
      </div>

      {/* Charts Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, marginBottom: 24 }}>
        {/* Revenue Chart */}
        <div className="chart-wrapper">
          <div className="chart-title">Doanh thu 6 tháng gần nhất</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueData} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis
                tick={{ fill: '#64748b', fontSize: 11 }}
                axisLine={false} tickLine={false}
                tickFormatter={v => `${v / 1000000}tr`}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(59,130,246,0.06)' }} />
              <Bar dataKey="revenue" fill="#3b82f6" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Status Pie */}
        <div className="chart-wrapper">
          <div className="chart-title">Trạng thái đơn hàng</div>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%" cy="50%"
                  innerRadius={55} outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {statusData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value, name) => [value + ' đơn', name]}
                  contentStyle={{
                    background: 'var(--bg-card)', border: '1px solid var(--border)',
                    borderRadius: 8, fontSize: 13
                  }}
                />
                <Legend
                  formatter={val => <span style={{ color: 'var(--text-secondary)', fontSize: 12 }}>{val}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="empty-state" style={{ padding: 40 }}>
              <div>Chưa có đơn hàng</div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Recent Orders */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Đơn hàng gần đây</span>
            <button className="btn btn-ghost btn-sm" onClick={() => navigate('/orders')}>Xem tất cả →</button>
          </div>
          <div className="table-wrapper">
            <table className="table">
              <thead>
                <tr>
                  <th>Khách hàng</th>
                  <th>Tổng tiền</th>
                  <th>Trạng thái</th>
                  <th>Ngày</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map(order => {
                  const badge = getOrderStatusBadge(order.status);
                  return (
                    <tr key={order.id}>
                      <td className="primary">{order.customerName}</td>
                      <td><span className="price">{formatCurrency(order.total)}</span></td>
                      <td><span className={`badge ${badge.cls}`}>{badge.label}</span></td>
                      <td>{formatDate(order.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Products & Low Stock */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Top Products */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Sản phẩm bán chạy</span>
            </div>
            <div style={{ padding: '16px 24px' }}>
              {topProducts.length > 0 ? topProducts.map((p, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                  <div style={{
                    width: 24, height: 24, borderRadius: 6,
                    background: i === 0 ? '#f59e0b' : i === 1 ? '#94a3b8' : 'var(--bg-card-hover)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 11, fontWeight: 700, color: i < 2 ? '#000' : 'var(--text-muted)',
                    flexShrink: 0
                  }}>{i + 1}</div>
                  <div style={{ flex: 1, fontSize: 13, color: 'var(--text-secondary)' }}>{p.name}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)' }}>{p.qty} sp</div>
                </div>
              )) : (
                <div style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center', padding: '10px 0' }}>
                  Chưa có dữ liệu
                </div>
              )}
            </div>
          </div>

          {/* Low Stock Alert */}
          {lowStockProducts.length > 0 && (
            <div className="card" style={{ borderColor: 'rgba(245,158,11,0.4)' }}>
              <div className="card-header" style={{ background: 'rgba(245,158,11,0.05)' }}>
                <span className="card-title">Sắp hết hàng ({lowStockProducts.length})</span>
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/products')}>Quản lý</button>
              </div>
              <div style={{ padding: '12px 20px' }}>
                {lowStockProducts.slice(0, 4).map(p => (
                  <div key={p.id} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13
                  }}>
                    <span style={{ color: 'var(--text-secondary)' }}>{p.name}</span>
                    <span className={`badge ${p.quantity < 5 ? 'badge-danger' : 'badge-warning'}`}>
                      {p.quantity} còn lại
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
