
import React, { useEffect, useState, useCallback } from 'react';
import { productsApi } from '../services/api';
import { formatCurrency, formatDate } from '../utils/format';
import Loading from '../components/Loading';
import Pagination from '../components/Pagination';
import ConfirmDialog from '../components/ConfirmDialog';
import toast from 'react-hot-toast';
import { Link, useSearchParams } from 'react-router-dom';

const BRANDS = ['Tất cả', 'Apple', 'Samsung', 'Xiaomi', 'OPPO', 'Vivo', 'Realme', 'Nokia', 'Khác'];
const PAGE_SIZE = 6;

// Form Modal
function ProductModal({ product, onClose, onSaved }) {
  const isEdit = !!product?.id;
  const [form, setForm] = useState({
    name: product?.name || '',
    brand: product?.brand || 'Apple',
    price: product?.price || '',
    quantity: product?.quantity || '',
    image: product?.image || '',
    colors: product?.colors ? product.colors.join(', ') : '',
    capacities: product?.capacities ? product.capacities.join(', ') : '',
    description: product?.description || '',
  });

  const [colorImages, setColorImages] = useState(() => {
    const initial = {};
    if (product?.colorImages) {
      Object.keys(product.colorImages).forEach(color => {
         initial[color] = product.colorImages[color].join(', ');
      });
    }
    return initial;
  });

  const [saving, setSaving] = useState(false);

  const handleChange = e => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.name.trim()) return toast.error('Vui lòng nhập tên sản phẩm');
    if (!form.price || form.price <= 0) return toast.error('Vui lòng nhập giá hợp lệ');
    if (!form.quantity || form.quantity < 0) return toast.error('Số lượng không hợp lệ');

    setSaving(true);
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        quantity: Number(form.quantity),
        colors: form.colors.split(',').map(s => s.trim()).filter(Boolean),
        capacities: form.capacities?.split(',').map(s => s.trim()).filter(Boolean),
      };

      const parsedColorImages = {};
      let firstGlobalImage = form.image; // fallback
      payload.colors.forEach(color => {
        const val = colorImages[color] || '';
        const list = val.split(',').map(s => s.trim()).filter(Boolean);
        parsedColorImages[color] = list;
        if (list.length > 0 && (!firstGlobalImage || firstGlobalImage === form.image)) {
           firstGlobalImage = list[0];
        }
      });
      
      payload.colorImages = parsedColorImages;
      payload.image = firstGlobalImage;
      // Removed old flat images array support from admin since we moved to colorImages.
      if (isEdit) {
        await productsApi.update(product.id, { ...product, ...payload });
        toast.success('Cập nhật sản phẩm thành công!');
      } else {
        await productsApi.create(payload);
        toast.success('Thêm sản phẩm thành công!');
      }
      onSaved();
    } catch {
      toast.error('Có lỗi xảy ra, vui lòng thử lại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose} style={{ overflowY: 'auto' }}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ margin: 'auto', maxHeight: '95vh' }}>
        <div className="modal-header">
          <h2 className="modal-title">{isEdit ? 'Sửa sản phẩm' : 'Thêm sản phẩm mới'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Tên sản phẩm <span>*</span></label>
                <input name="name" className="form-control" value={form.name}
                  onChange={handleChange} placeholder="VD: iPhone 15 Pro Max" />
              </div>
              <div className="form-group">
                <label className="form-label">Hãng sản xuất <span>*</span></label>
                <select name="brand" className="form-control" value={form.brand} onChange={handleChange}>
                  {BRANDS.filter(b => b !== 'Tất cả').map(b => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Giá bán (VNĐ) <span>*</span></label>
                <input name="price" type="number" className="form-control" value={form.price}
                  onChange={handleChange} placeholder="VD: 15990000" min="0" />
              </div>
              <div className="form-group">
                <label className="form-label">Số lượng tồn kho <span>*</span></label>
                <input name="quantity" type="number" className="form-control" value={form.quantity}
                  onChange={handleChange} placeholder="VD: 50" min="0" />
              </div>
            </div>

            <div className="form-group">
               <label className="form-label">Danh sách màu sắc (Cách nhau bởi dấu phẩy)</label>
               <input name="colors" className="form-control" value={form.colors} onChange={handleChange} placeholder="Titan Đen, Titan Trắng..." />
            </div>

            {form.colors.split(',').map(s => s.trim()).filter(Boolean).map((color, idx) => (
               <div className="form-group" key={idx} style={{ paddingLeft: 16, borderLeft: '3px solid var(--accent)' }}>
                  <label className="form-label">Link ảnh cho màu <strong>{color}</strong> (Cách nhau bởi dấu phẩy)</label>
                  <textarea 
                     className="form-control" 
                     value={colorImages[color] || ''} 
                     onChange={(e) => setColorImages(prev => ({ ...prev, [color]: e.target.value }))} 
                     placeholder={`https://img1.jpg, https://img2.jpg cho màu ${color}...`} 
                     rows={2} 
                  />
               </div>
            ))}

            <div className="form-group">
               <label className="form-label">Danh sách dung lượng (Cách nhau bởi dấu phẩy)</label>
               <input name="capacities" className="form-control" value={form.capacities} onChange={handleChange} placeholder="128GB, 256GB, 512GB..." />
            </div>

            <div className="form-group">
              <label className="form-label">Mô tả sản phẩm</label>
              <textarea name="description" className="form-control" value={form.description}
                onChange={handleChange} placeholder="Mô tả ngắn về sản phẩm..." rows={3} />
            </div>

            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={onClose}>Huỷ</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Đang lưu...</> : (isEdit ? 'Cập nhật' : 'Thêm mới')}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

// Main Page
export default function AdminProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const [searchParams] = useSearchParams();
  const search = searchParams.get('search') || '';
  const brandFilter = searchParams.get('brand') || 'Tất cả';

  const [sortBy, setSortBy] = useState('');
  const [page, setPage] = useState(1);
  const [searchName, setSearchName] = useState('');
  const [modalProduct, setModalProduct] = useState(undefined);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Fetch danh sách sản phẩm
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await productsApi.getAll();
      setProducts(res.data);
    } catch {
      toast.error('Không thể tải danh sách sản phẩm');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  // Reset page khi filter thay đổi
  useEffect(() => { setPage(1); }, [search, brandFilter, sortBy, searchName]);

  // Lọc & sắp xếp
  let filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.brand.toLowerCase().includes(search.toLowerCase());
    const matchBrand = brandFilter === 'Tất cả' || p.brand === brandFilter;
    const matchName = searchName.trim() === '' || p.name.toLowerCase().includes(searchName.toLowerCase());
    return matchSearch && matchBrand && matchName;
  });

  if (sortBy === 'price_asc') filtered.sort((a, b) => a.price - b.price);
  else if (sortBy === 'price_desc') filtered.sort((a, b) => b.price - a.price);
  else if (sortBy === 'name') filtered.sort((a, b) => a.name.localeCompare(b.name));

  // Phân trang
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Xoá sản phẩm
  const handleDelete = async () => {
    setDeleting(true);
    try {
      await productsApi.delete(deleteTarget.id);
      toast.success('Đã xoá sản phẩm!');
      setDeleteTarget(null);
      fetchProducts();
    } catch {
      toast.error('Xoá thất bại');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <Loading text="Đang tải sản phẩm..." />;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Quản lý sản phẩm</div>
          <div className="page-subtitle">{products.length} sản phẩm trong kho</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModalProduct(null)}>
          Thêm sản phẩm
        </button>
      </div>

      {/* Toolbar */}
      <div className="toolbar" style={{ justifyContent: 'space-between', borderBottom: '1px solid var(--border)', paddingBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <h2 style={{ fontSize: 20, margin: 0, fontWeight: 700 }}>
          {search
            ? `Kết quả tìm kiếm cho "${search}"`
            : brandFilter !== 'Tất cả'
              ? `Điện thoại ${brandFilter}`
              : 'Tất cả sản phẩm'
          }
        </h2>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <input 
            className="form-control" 
            placeholder="Tìm theo tên sản phẩm..." 
            value={searchName} 
            onChange={e => setSearchName(e.target.value)} 
            style={{ width: 220, height: 36, fontSize: 13 }} 
          />
          <select
            className="filter-select"
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
          >
            <option value="">Sắp xếp mặc định</option>
            <option value="price_asc">Giá thấp → cao</option>
            <option value="price_desc">Giá cao → thấp</option>
            <option value="name">Tên A → Z</option>
          </select>
        </div>
      </div>

      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"></div>
            <h3>Không tìm thấy sản phẩm</h3>
            <p>Thử thay đổi bộ lọc hoặc từ khoá tìm kiếm</p>
          </div>
        ) : (
          <>
            <div className="table-wrapper">
              <table className="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Sản phẩm</th>
                    <th>Giá bán</th>
                    <th>Tồn kho</th>
                    <th>Hình ảnh</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((product, idx) => (
                    <tr key={product.id}>
                      <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>
                        {(page - 1) * PAGE_SIZE + idx + 1}
                      </td>
                      <td>
                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                          <span style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: 14 }}>
                            {product.name}
                          </span>
                          <span style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 2 }}>
                            {product.brand}
                          </span>
                        </div>
                      </td>
                      <td><span className="price">{formatCurrency(product.price)}</span></td>
                      <td>
                        <span className={`badge ${product.quantity === 0 ? 'badge-danger' :
                          product.quantity < 10 ? 'badge-warning' : 'badge-success'
                          }`}>
                          {product.quantity === 0 ? 'Hết hàng' : `Còn ${product.quantity}`}
                        </span>
                      </td>
                      <td>
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            style={{ width: 44, height: 44, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }}
                            onError={(e) => {
                              e.target.style.display = 'none';
                            }}
                          />
                        ) : (
                          <div style={{ width: 44, height: 44, borderRadius: 8, background: 'var(--bg-input)', border: '1px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: 'var(--text-muted)' }}>No img</div>
                        )}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button
                            className="btn-icon"
                            title="Sửa"
                            onClick={() => setModalProduct(product)}
                          >
                            Sửa
                          </button>
                          <button
                            className="btn-icon danger"
                            title="Xoá"
                            onClick={() => setDeleteTarget(product)}
                          >
                            Xoá
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              page={page}
              totalPages={totalPages}
              total={filtered.length}
              pageSize={PAGE_SIZE}
              onPageChange={setPage}
            />
          </>
        )}
      </div>

      {/* Add/Edit Modal */}
      {modalProduct !== undefined && (
        <ProductModal
          product={modalProduct}
          onClose={() => setModalProduct(undefined)}
          onSaved={() => { setModalProduct(undefined); fetchProducts(); }}
        />
      )}

      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        title="Xoá sản phẩm"
        message={`Bạn có chắc muốn xoá "${deleteTarget?.name}"? Hành động này không thể hoàn tác.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        loading={deleting}
      />
    </div>
  );
}
