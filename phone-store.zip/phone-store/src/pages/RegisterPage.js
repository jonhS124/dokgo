import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../utils/AuthContext';
import toast from 'react-hot-toast';

/**
 * RegisterPage: Trang đăng ký tài khoản mới (Simple)
 */
export default function RegisterPage() {
  const { register, loading } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '', email: '', phone: '',
    username: '', password: '', confirmPassword: ''
  });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');

  const handleChange = e => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  // Validate email format
  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  // Validate phone format (VN)
  const isValidPhone = (phone) => /^(0[3-9])\d{8}$/.test(phone.replace(/\s/g, ''));

  const handleSubmit = async e => {
    e.preventDefault();

    // Validation
    if (!form.name.trim()) { setError('Vui lòng nhập họ và tên'); return; }
    if (!form.email.trim()) { setError('Vui lòng nhập email'); return; }
    if (!isValidEmail(form.email)) { setError('Email không hợp lệ'); return; }
    if (!form.phone.trim()) { setError('Vui lòng nhập số điện thoại'); return; }
    if (!isValidPhone(form.phone)) { setError('Số điện thoại không hợp lệ (VD: 0901234567)'); return; }
    if (!form.username.trim()) { setError('Vui lòng nhập tên đăng nhập'); return; }
    if (form.username.length < 3) { setError('Tên đăng nhập phải có ít nhất 3 ký tự'); return; }
    if (!form.password) { setError('Vui lòng nhập mật khẩu'); return; }
    if (form.password.length < 6) { setError('Mật khẩu phải có ít nhất 6 ký tự'); return; }
    if (form.password !== form.confirmPassword) { setError('Mật khẩu xác nhận không khớp'); return; }

    const result = await register({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      username: form.username.trim(),
      password: form.password,
    });

    if (result.success) {
      toast.success('Đăng ký thành công');
      navigate('/products');
    } else {
      setError(result.message);
      toast.error(result.message);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card" style={{ maxWidth: 440 }}>
        {/* Form */}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Họ và tên <span>*</span></label>
            <input type="text" name="name" className="form-control"
              placeholder="" value={form.name}
              onChange={handleChange} autoFocus />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Email <span>*</span></label>
              <input type="email" name="email" className="form-control"
                placeholder="" value={form.email}
                onChange={handleChange} />
            </div>
            <div className="form-group">
              <label className="form-label">Số điện thoại <span>*</span></label>
              <input type="tel" name="phone" className="form-control"
                placeholder="" value={form.phone}
                onChange={handleChange} />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Tên đăng nhập <span>*</span></label>
            <input type="text" name="username" className="form-control"
              placeholder="Ít nhất 3 ký tự" value={form.username}
              onChange={handleChange} />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Mật khẩu <span>*</span></label>
              <div style={{ position: 'relative' }}>
                <input type={showPass ? 'text' : 'password'} name="password"
                  className="form-control" placeholder="Ít nhất 6 ký tự"
                  value={form.password} onChange={handleChange}
                  style={{ paddingRight: 40 }} />
                <button type="button" onClick={() => setShowPass(p => !p)}
                  style={{
                    position: 'absolute', right: 10, top: '50%',
                    transform: 'translateY(-50%)', background: 'none',
                    border: 'none', color: 'var(--text-muted)',
                    cursor: 'pointer', fontSize: 15
                  }}>
                  {showPass ? '🙈' : '👁'}
                </button>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Xác nhận <span>*</span></label>
              <input type={showPass ? 'text' : 'password'} name="confirmPassword"
                className="form-control" placeholder="Nhập lại mật khẩu"
                value={form.confirmPassword} onChange={handleChange} />
            </div>
          </div>

          {error && (
            <div style={{
              background: 'var(--danger-light)',
              border: '1px solid rgba(239,68,68,0.3)',
              borderRadius: 8, padding: '10px 14px',
              fontSize: 13, color: 'var(--danger)', marginBottom: 16
            }}>⚠️ {error}</div>
          )}

          <button type="submit" className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center', padding: '13px', fontSize: 15 }}
            disabled={loading}>
            {loading ? (
              <><span className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} /> Đang đăng ký...</>
            ) : 'Đăng ký ngay'}
          </button>

          <div style={{
            marginTop: 20, textAlign: 'center',
            fontSize: 14, color: 'var(--text-muted)'
          }}>
            Đã có tài khoản?{' '}
            <Link to="/login" style={{ color: 'var(--accent)', fontWeight: 600 }}>
              Đăng nhập
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
