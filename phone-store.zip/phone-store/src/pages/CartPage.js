import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../utils/AuthContext';
import { useCart } from '../utils/CartContext';

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart, clearCart, cartTotal } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  if (cart.length === 0) {
    return (
      <div className="page-body">
        <div className="page-header">
          <h1 className="page-title">Giỏ hàng của bạn</h1>
        </div>
        <div className="card">
          <div className="empty-state">
            <div className="empty-icon"></div>
            <h3>Giỏ hàng đang trống</h3>
            <p>Hãy chọn cho mình những sản phẩm yêu thích nhé!</p>
            <button className="btn btn-primary" onClick={() => navigate('/products')} style={{ marginTop: 20 }}>
              Tiếp tục mua sắm
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-body">
      <div className="page-header">
        <div>
          <h1 className="page-title">Giỏ hàng của bạn</h1>
          <p className="page-subtitle">Kiểm tra lại các sản phẩm trước khi thanh toán</p>
        </div>
      </div>

      <div className="form-row" style={{ gridTemplateColumns: '2fr 1fr', gap: '24px', alignItems: 'start' }}>
        {/* Cart Items List */}
        <div className="card">
          <div className="table-wrapper">
            <table className="table">
              <thead>
                <tr>
                  <th>Sản phẩm</th>
                  <th>Đơn giá</th>
                  <th style={{ width: 120 }}>Số lượng</th>
                  <th style={{ textAlign: 'right' }}>Thành tiền</th>
                  <th style={{ width: 60 }}></th>
                </tr>
              </thead>
              <tbody>
                {cart.map(item => (
                  <tr key={item.product.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        {item.product.image ? (
                          <img 
                            src={item.product.image} 
                            alt={item.product.name} 
                            style={{ width: 44, height: 44, objectFit: 'cover', borderRadius: 8, background: '#fff' }} 
                          />
                        ) : (
                          <div className="product-img-placeholder"></div>
                        )}
                        <div>
                          <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{item.product.name}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{item.product.brand}</div>
                        </div>
                      </div>
                    </td>
                    <td className="price">{formatCurrency(item.product.price)}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <button 
                          className="btn-icon" 
                          style={{ width: 28, height: 28, padding: 0 }}
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          -
                        </button>
                        <span style={{ width: 24, textAlign: 'center', fontWeight: 600 }}>{item.quantity}</span>
                        <button 
                          className="btn-icon" 
                          style={{ width: 28, height: 28, padding: 0 }}
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        >
                          +
                        </button>
                      </div>
                    </td>
                    <td className="price" style={{ textAlign: 'right' }}>
                      {formatCurrency(item.product.price * item.quantity)}
                    </td>
                    <td>
                      <button 
                        className="btn-icon danger" 
                        title="Xoá"
                        onClick={() => removeFromCart(item.product.id)}
                      >
                        Xoá
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Checkout Panel */}
        <div className="card sticky" style={{ position: 'sticky', top: '100px' }}>
          <div className="card-header">
            <h2 className="card-title">Tổng quan đơn hàng</h2>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <span style={{ color: 'var(--text-secondary)' }}>Tạm tính ({cart.length} sản phẩm):</span>
              <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{formatCurrency(cartTotal)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24, alignItems: 'center' }}>
              <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)' }}>Tổng cộng:</span>
              <span className="price" style={{ fontSize: 24 }}>{formatCurrency(cartTotal)}</span>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: 16 }}
              onClick={() => navigate('/checkout')}
            >
              Tiến hành thanh toán
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
