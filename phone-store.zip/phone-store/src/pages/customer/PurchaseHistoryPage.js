import React, { useState, useEffect } from 'react';
import { ordersApi } from '../../services/api';
import { useAuth } from '../../utils/AuthContext';

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('vi-VN') + ' ' + d.toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'});
};

const getOrderStatusBadge = (status) => {
  switch (status) {
    case 'Pending': return { label: 'Chờ xử lý', cls: 'badge-warning' };
    case 'Completed': return { label: 'Hoàn thành', cls: 'badge-success' };
    case 'Cancelled': return { label: 'Đã huỷ', cls: 'badge-danger' };
    default: return { label: status, cls: 'badge-secondary' };
  }
};

export default function PurchaseHistoryPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filter States
  const [searchId, setSearchId] = useState('');
  const [searchProduct, setSearchProduct] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await ordersApi.getAll();
        const historyOrders = res.data.filter(
          o => o.customerId === user.id && (o.status === 'Completed' || o.status === 'Cancelled')
        );
        setOrders(historyOrders.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (user) fetchOrders();
  }, [user]);

  if (loading) return <div style={{ padding: 40, textAlign: 'center' }}>Đang tải lịch sử...</div>;

  const filteredOrders = orders.filter(o => {
    const cleanSearchId = searchId.replace('#', '').trim();
    const displayId = String(o.id).padStart(4, '0');
    const matchId = cleanSearchId === '' || displayId.includes(cleanSearchId);
    const matchProduct = searchProduct.trim() === '' || 
      o.items?.some(i => i.productName.toLowerCase().includes(searchProduct.toLowerCase()));
    
    // UI filter option values: 'Hoàn thành', 'Đã huỷ' Map them to internal English states.
    const mappedFilterTarget = filterStatus === 'Hoàn thành' ? 'Completed' : (filterStatus === 'Đã huỷ' ? 'Cancelled' : '');
    const matchStatus = mappedFilterTarget === '' || o.status === mappedFilterTarget;

    return matchId && matchProduct && matchStatus;
  });

  return (
    <div>
      <h2 className="profile-page-title">Lịch sử mua hàng (Đã hoàn tất/Đã huỷ)</h2>
      
      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <input className="form-control" placeholder="Nhập mã đơn..." style={{ flex: 1, minWidth: 150 }} 
               value={searchId} onChange={e => setSearchId(e.target.value)} />
        <input className="form-control" placeholder="Nhập tên sản phẩm..." style={{ flex: 1, minWidth: 150 }} 
               value={searchProduct} onChange={e => setSearchProduct(e.target.value)} />
        <select className="form-control" style={{ width: 180 }} 
                value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">-- Tất cả trạng thái --</option>
          <option value="Hoàn thành">Hoàn thành</option>
          <option value="Đã huỷ">Đã huỷ</option>
        </select>
      </div>

      {orders.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-muted)' }}>
          Bạn chưa có lịch sử mua hàng nào
        </div>
      ) : (
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr style={{ background: '#f8f9fa' }}>
                <th>Mã đơn</th>
                <th>Sản phẩm</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Ngày tạo</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map(order => {
                const badge = getOrderStatusBadge(order.status);
                return (
                  <tr key={order.id}>
                    <td style={{ fontFamily: 'var(--font-mono)' }}>#{String(order.id).padStart(4, '0')}</td>
                    <td>
                      {order.items?.map(i => `${i.productName} ×${i.quantity}`).join(', ')}
                    </td>
                    <td className="price">{formatCurrency(order.total)}</td>
                    <td><span className={`badge ${badge.cls}`}>{badge.label}</span></td>
                    <td>{formatDate(order.createdAt)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
