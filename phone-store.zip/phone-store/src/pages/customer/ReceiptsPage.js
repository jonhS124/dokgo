import React from 'react';

export default function ReceiptsPage() {
  return (
    <div>
      <h2 className="profile-page-title">Phiếu nhận máy</h2>
      
      {/* Progress tracker skeleton */}
      <div style={{ display: 'flex', justifyContent: 'center', margin: '40px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', position: 'relative', width: '100%', maxWidth: 600 }}>
          {/* Progress bar background */}
          <div style={{ position: 'absolute', top: '50%', transform: 'translateY(-50%)', left: 0, right: 0, height: 2, background: 'var(--border)', zIndex: 0 }}></div>
          
          {/* Steps */}
          {[1,2,3,4,5,6,7,8,9,10,11,12].map((step, idx) => (
             <div key={idx} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', zIndex: 1 }}>
               <div style={{ width: 14, height: 14, borderRadius: '50%', background: 'white', border: '2px solid var(--border)' }}></div>
               {idx === 4 || idx === 9 || idx === 11 ? (
                 <div style={{ position: 'absolute', top: 20, fontSize: 13, color: 'var(--text-secondary)' }}>{idx + 1}</div>
               ) : null}
             </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 32, flexWrap: 'wrap' }}>
        <input className="form-control" placeholder="Nhập mã phiếu sửa..." style={{ flex: 1, minWidth: 150 }} />
        <input className="form-control" placeholder="Nhập tên sản phẩm..." style={{ flex: 1, minWidth: 150 }} />
        <input className="form-control" placeholder="01/01/2021 - 27/03/2026" style={{ width: 220 }} />
        <button className="btn" style={{ border: '1px solid var(--border)', background: 'white', padding: '0 24px', borderRadius: 4 }}>Tìm kiếm</button>
      </div>

      <div style={{ fontWeight: 700, color: 'var(--accent)', marginBottom: 16 }}>Danh sách phiếu sửa</div>
      <div style={{ padding: '24px 0', borderTop: '1px solid var(--border)', fontSize: 15, color: '#000' }}>
        Không có phiếu sửa phù hợp!
      </div>
    </div>
  );
}
