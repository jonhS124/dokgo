import React, { useState, useEffect } from 'react';
import { useAuth } from '../../utils/AuthContext';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  
  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    gender: user?.gender || 'Nam',
    day: String(user?.dob?.day || '27'),
    month: String(user?.dob?.month || '3'),
    year: String(user?.dob?.year || '2026')
  });

  useEffect(() => {
    if (user) {
      setForm({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        gender: user.gender || 'Nam',
        day: String(user.dob?.day || '27'),
        month: String(user.dob?.month || '3'),
        year: String(user.dob?.year || '2026')
      });
    }
  }, [user]);

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return toast.error('Vui lòng nhập họ và tên');
    if (!form.phone.trim()) return toast.error('Vui lòng nhập số điện thoại');
    
    setLoading(true);
    const updatedData = {
      name: form.name,
      email: form.email,
      phone: form.phone,
      gender: form.gender,
      dob: {
        day: form.day,
        month: form.month,
        year: form.year
      }
    };

    const res = await updateProfile(user.id, updatedData);
    setLoading(false);

    if (res.success) {
      toast.success('Cập nhật thông tin thành công!');
    } else {
      toast.error(res.message || 'Cập nhật thất bại');
    }
  };

  return (
    <div>
      <h2 className="profile-page-title">Thông tin tài khoản</h2>
      <form onSubmit={handleSubmit} style={{ maxWidth: 600 }}>
        
        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', alignItems: 'center', marginBottom: 20 }}>
          <label style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Họ và tên</label>
          <input className="form-control" name="name" value={form.name} onChange={handleChange} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr auto', gap: '0 12px', alignItems: 'center', marginBottom: 20 }}>
          <label style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Email</label>
          <input className="form-control" name="email" value={form.email} onChange={handleChange} />
          <span style={{ fontSize: 13, color: '#3b82f6', cursor: 'pointer' }}>Thay đổi</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr auto', gap: '0 12px', alignItems: 'center', marginBottom: 20 }}>
          <label style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Số điện thoại</label>
          <input className="form-control" name="phone" value={form.phone} onChange={handleChange} placeholder="Chưa cập nhật" />
          <span style={{ fontSize: 13, color: '#3b82f6', cursor: 'pointer' }}>Thay đổi</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', alignItems: 'center', marginBottom: 20 }}>
          <label style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Giới tính</label>
          <div style={{ display: 'flex', gap: 24 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14 }}>
              <input type="radio" name="gender" value="Nam" checked={form.gender === 'Nam'} onChange={handleChange} /> Nam
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14 }}>
              <input type="radio" name="gender" value="Nữ" checked={form.gender === 'Nữ'} onChange={handleChange} /> Nữ
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14 }}>
              <input type="radio" name="gender" value="Khác" checked={form.gender === 'Khác'} onChange={handleChange} /> Khác
            </label>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', alignItems: 'center', marginBottom: 24 }}>
          <label style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Ngày sinh</label>
          <div style={{ display: 'flex', gap: 12 }}>
            <select className="form-control" name="day" value={String(form.day)} onChange={handleChange}>
              {[...Array(31)].map((_, i) => <option key={i+1} value={String(i+1)}>{i+1}</option>)}
            </select>
            <select className="form-control" name="month" value={String(form.month)} onChange={handleChange}>
              {[...Array(12)].map((_, i) => <option key={i+1} value={String(i+1)}>Tháng {i+1}</option>)}
            </select>
            <select className="form-control" name="year" value={String(form.year)} onChange={handleChange}>
              {[...Array(60)].map((_, i) => {
                const year = 2026 - i;
                return <option key={year} value={String(year)}>{year}</option>
              })}
            </select>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', alignItems: 'center', marginBottom: 32 }}>
          <div></div>
          <span style={{ fontSize: 13, color: '#3b82f6', cursor: 'pointer' }}>Thay đổi mật khẩu</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', alignItems: 'center' }}>
          <div></div>
          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ padding: '12px 32px', fontSize: 15, fontWeight: 700, width: 'fit-content' }}
            disabled={loading}
          >
            {loading ? 'ĐANG LƯU...' : 'CẬP NHẬT'}
          </button>
        </div>
      </form>
    </div>
  );
}
