import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../utils/AuthContext';
import { useCart } from '../utils/CartContext';
import toast from 'react-hot-toast';

// Swiper
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Thumbs, FreeMode } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/thumbs';
import 'swiper/css/free-mode';

import './ProductDetailsPage.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

export default function ProductDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const isAdmin = user?.role === 'admin';
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  // States for variants & swiper
  const [mainSwiper, setMainSwiper] = useState(null);
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedCapacity, setSelectedCapacity] = useState('256GB');

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${API_URL}/products/${id}`);
      const p = res.data;
      setProduct(p);
      
      // Auto select first color if exists
      if (p.colors && p.colors.length > 0) {
        setSelectedColor(p.colors[0]);
      }
    } catch (err) {
      toast.error('Không tìm thấy sản phẩm!');
      navigate('/products');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  const handleColorSelect = (color, idx) => {
    setSelectedColor(color);
    if (mainSwiper) {
      mainSwiper.slideTo(0); // Reset về ảnh đầu tiên của màu
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <div className="loading-text">Đang tải thông tin sản phẩm...</div>
      </div>
    );
  }

  if (!product) return null;

  const hasColors = product.colors && product.colors.length > 0;

  // Xử lý list ảnh: Ưu tiên dùng `colorImages` phân theo màu đang chọn
  let imagesList = [];
  if (product.colorImages && Object.keys(product.colorImages).length > 0 && selectedColor) {
    imagesList = product.colorImages[selectedColor] || [];
  }
  // Fallback: nếu màu chưa có ảnh hoặc sp đời cũ, lấy hình chung
  if (imagesList.length === 0) {
    imagesList = product.images && product.images.length > 0 
      ? product.images 
      : (product.image ? [product.image] : []);
  }

  return (
    <div className="page-body">
      <button className="btn btn-ghost" onClick={() => navigate('/products')} style={{ marginBottom: 24 }}>
        ← Trang chủ / Điện thoại / {product.brand} / {product.name}
      </button>

      <div className="product-details-container" style={{ display: 'grid', gridTemplateColumns: 'minmax(400px, 4fr) 5fr', gap: '32px', alignItems: 'start' }}>
        
        {/* =======================
            CỘT TRÁI: THƯ VIỆN ẢNH (SLIDER)
        ======================== */}
        <div style={{ position: 'sticky', top: '24px' }}>
          <div className="product-gallery">
            {imagesList.length > 0 ? (
              <>
                {/* Ảnh Chính */}
                <Swiper
                  onSwiper={setMainSwiper}
                  spaceBetween={10}
                  navigation={true}
                  thumbs={{ swiper: thumbsSwiper && !thumbsSwiper.destroyed ? thumbsSwiper : null }}
                  modules={[FreeMode, Navigation, Thumbs]}
                  className="gallery-main"
                >
                  {imagesList.map((imgUrl, idx) => (
                    <SwiperSlide key={idx} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                      <img src={imgUrl} alt={`${product.name} - slide ${idx}`} />
                    </SwiperSlide>
                  ))}
                </Swiper>

                {/* Danh sách Ảnh Thu Nhỏ */}
                {imagesList.length > 1 && (
                  <Swiper
                    onSwiper={setThumbsSwiper}
                    spaceBetween={12}
                    slidesPerView={5}
                    freeMode={true}
                    watchSlidesProgress={true}
                    modules={[FreeMode, Navigation, Thumbs]}
                    className="gallery-thumbs"
                  >
                    {imagesList.map((imgUrl, idx) => (
                      <SwiperSlide key={`thumb-${idx}`} className="gallery-thumb-slide">
                        <img src={imgUrl} alt={`thumb ${idx}`} />
                      </SwiperSlide>
                    ))}
                  </Swiper>
                )}
              </>
            ) : (
              <div className="gallery-main" style={{ background: 'var(--bg-input)' }}>
                 <div style={{ color: 'var(--text-muted)' }}>Chưa có hình ảnh</div>
              </div>
            )}
          </div>
          
          {/* Thông số bên dưới slider (mô phỏng FPT) */}
          <div style={{ marginTop: 24, padding: '24px 20px', background: '#fff', borderRadius: 12, border: '1px solid var(--border)' }}>
            <h3 style={{ fontSize: 18, marginBottom: 20 }}>Thông số nổi bật</h3>
            <div className="specs-snippet">
              <div className="spec-item">
                <div className="spec-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6366f1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                </div>
                <div className="spec-info">
                  <div className="label">Kích thước màn hình</div>
                  <div className="val">6.7 inch</div>
                </div>
              </div>
              <div className="spec-item">
                <div className="spec-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="6" width="16" height="12" rx="2" ry="2"></rect><line x1="2" y1="12" x2="2.01" y2="12"></line><line x1="10" y1="9" x2="10" y2="15"></line></svg>
                </div>
                <div className="spec-info">
                  <div className="label">Thời lượng pin</div>
                  <div className="val">29 Giờ</div>
                </div>
              </div>
              <div className="spec-item">
                <div className="spec-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h.01"></path><path d="M2 8.82a15 15 0 0 1 20 0"></path><path d="M5 12.82a10 10 0 0 1 14 0"></path><path d="M8.5 16.42a5 5 0 0 1 7 0"></path></svg>
                </div>
                <div className="spec-info">
                  <div className="label">Kết nối NFC</div>
                  <div className="val">NFC</div>
                </div>
              </div>
            </div>
            
            <div style={{ display: 'flex', gap: 24, justifyContent: 'space-between' }}>
               <div style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 13, color: 'var(--text-secondary)' }}>
                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="var(--danger)" stroke="var(--danger)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg> 
                 Hàng chính hãng - Bảo hành 12 tháng
               </div>
               <div style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 13, color: 'var(--text-secondary)' }}>
                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
                 Miễn phí giao hàng toàn quốc
               </div>
            </div>
          </div>
        </div>

        {/* =======================
            CỘT PHẢI: THÔNG TIN & MUA
        ======================== */}
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '8px', lineHeight: 1.3 }}>
            {product.name}
          </h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: '24px', fontSize: 13 }}>
            <span style={{ color: 'var(--text-muted)' }}>Mã SP: {String(product.id).padStart(6, '0')}</span>
            <span style={{ color: 'var(--warning)', fontWeight: 700 }}>★ 4.9 <span style={{ color: 'var(--accent)', cursor: 'pointer', marginLeft: 4 }}>397 đánh giá</span></span>
            <span style={{ color: 'var(--accent)', cursor: 'pointer', borderLeft: '1px solid var(--border)', paddingLeft: 12 }}>Thông số kỹ thuật</span>
          </div>
          
          {/* Dung lượng Options (Dựa trên DB) */}
          <div className="variant-group">
            <span className="variant-label">Dung lượng</span>
            <div className="variant-options">
              {(product.capacities && product.capacities.length > 0 ? product.capacities : ['256GB', '512GB', '1TB']).map(cap => (
                <button 
                  key={cap}
                  className={`capacity-btn ${selectedCapacity === cap ? 'active' : ''}`}
                  onClick={() => setSelectedCapacity(cap)}
                >
                  {cap}
                </button>
              ))}
            </div>
          </div>

          {/* Màu sắc Options (Dựa trên DB) */}
          <div className="variant-group">
            <span className="variant-label">Màu sắc</span>
            <div className="variant-options">
              {hasColors ? (
                product.colors.map((color, idx) => {
                  // Lấy hình đại diện cho nút màu
                  let thumbImg = null;
                  if (product.colorImages && product.colorImages[color] && product.colorImages[color].length > 0) {
                     thumbImg = product.colorImages[color][0];
                  } else {
                     // Fallback ngược về thuật toán cũ
                     const fallbackImgs = product.images && product.images.length > 0 ? product.images : (product.image ? [product.image] : []);
                     const chunk = Math.floor(fallbackImgs.length / (product.colors.length || 1));
                     thumbImg = fallbackImgs[Math.max(0, chunk) * idx] || fallbackImgs[0];
                  }

                  return (
                    <button 
                      key={idx}
                      className={`color-btn ${selectedColor === color ? 'active' : ''}`}
                      onClick={() => handleColorSelect(color, idx)}
                    >
                      {thumbImg ? <img src={thumbImg} className="color-thumb" alt={color} /> : <div className="color-thumb" />}
                      {color}
                    </button>
                  );
                })
              ) : (
                <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>Mặc định</div>
              )}
            </div>
          </div>

          {/* Khung Giá tiền */}
          <div className="price-box">
             <div className="price-main">{formatCurrency(product.price)}</div>
          </div>

          {/* Admin Info */}
          {isAdmin && (
            <div style={{ marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span className={`badge ${product.quantity === 0 ? 'badge-danger' : product.quantity < 10 ? 'badge-warning' : 'badge-success'}`}>
                  {product.quantity === 0 ? 'Hết hàng' : `Tồn kho: ${product.quantity} cái`}
              </span>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>(Chỉ Admin thấy thông tin này)</span>
            </div>
          )}

          {/* Nút Mua */}
          <button 
            className="btn btn-primary" 
            style={{ width: '100%', justifyContent: 'center', padding: '16px', fontSize: '18px', fontWeight: 800, textTransform: 'uppercase', borderRadius: 12, marginBottom: 24 }}
            onClick={() => addToCart(product)}
            disabled={product.quantity === 0}
          >
            {product.quantity === 0 ? 'HẾT HÀNG' : 'MUA NGAY'}
          </button>

          {/* Bảng Thông số kỹ thuật chi tiết (Scrollable) */}
          <div className="tech-specs-box">
             <div className="tech-specs-header">
                <h3>Thông số kỹ thuật</h3>
             </div>
             <div className="tech-specs-content">
               <ul className="specs-list">
                 <li><span className="spec-name">Màn hình:</span> <span className="spec-val">6.7 inch, Super Retina XDR OLED, 120Hz</span></li>
                 <li><span className="spec-name">Hệ điều hành:</span> <span className="spec-val">iOS 17</span></li>
                 <li><span className="spec-name">Camera sau:</span> <span className="spec-val">Chính 48 MP & Phụ 12 MP, 12 MP</span></li>
                 <li><span className="spec-name">Camera trước:</span> <span className="spec-val">12 MP</span></li>
                 <li><span className="spec-name">Chip:</span> <span className="spec-val">Apple A17 Pro 6 nhân</span></li>
                 <li><span className="spec-name">RAM:</span> <span className="spec-val">8 GB</span></li>
                 <li><span className="spec-name">Dung lượng:</span> <span className="spec-val">{selectedCapacity}</span></li>
                 <li><span className="spec-name">SIM:</span> <span className="spec-val">1 Nano SIM & 1 eSIM, Hỗ trợ 5G</span></li>
                 <li><span className="spec-name">Pin, Sạc:</span> <span className="spec-val">4422 mAh, 20 W</span></li>
                 <li><span className="spec-name">Chất liệu:</span> <span className="spec-val">Khung Titanium & Mặt kính cường lực</span></li>
                 <li><span className="spec-name">Trọng lượng:</span> <span className="spec-val">221 g</span></li>
               </ul>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
}
