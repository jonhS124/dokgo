import React, { useEffect, useState, useCallback } from 'react';
import { customersApi, ordersApi } from '../services/api';
import { formatDate, formatCurrency } from '../utils/format';
import Loading from '../components/Loading';
import Pagination from '../components/Pagination';
import ConfirmDialog from '../components/ConfirmDialog';
import toast from 'react-hot-toast';

const PAGE_SIZE = 7;

// ===== Customer Form Modal =====
function CustomerModal({ customer, onClose, onSaved }) {
  const isEdit = !!customer?.id;
  const [form, setForm] = useState({
    name: customer?.name || '',
    phone: customer?.phone || '',
    email: customer?.email || '',
    address: customer?.address || '',
  });
  const [saving, setSaving] = useState(false);

  const handleChange = e =>
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const validate = () => {
    if (!form.name.trim()) { toast.error('Vui lòng nhập họ tên'); return false; }
    if (!form.phone.trim()) { toast.error('Vui lòng nhập số điện thoại'); return false; }
    if (!/^0\d{9}$/.test(form.phone.trim())) {
      toast.error('Số điện thoại không hợp lệ (VD: 0901234567)'); return false;
    }
    return true;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      if (isEdit) {
        await customersApi.update(customer.id, { ...customer, ...form });
        toast.success(' Cập nhật khách hàng thành công!');
      } else {
        await customersApi.create(form);
        toast.success(' Thêm khách hàng thành công!');
      }
      onSaved();
    } catch {
      toast.error('Có lỗi xảy ra');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">{isEdit ? 'Sửa thông tin khách hàng' : 'Thêm khách hàng mới'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Họ và tên <span>*</span></label>
              <input name="name" className="form-control" value={form.name}
                onChange={handleChange} placeholder="Nguyễn Văn A" autoFocus />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Số điện thoại <span>*</span></label>
                <input name="phone" className="form-control" value={form.phone}
                  onChange={handleChange} placeholder="0901234567" />
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input name="email" type="email" className="form-control" value={form.email}
                  onChange={handleChange} placeholder="email@example.com" />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Địa chỉ</label>
              <textarea name="address" className="form-control" value={form.address}
                onChange={handleChange} placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành phố"
                rows={2} />
            </div>

            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={onClose}>Huỷ</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving
                  ? <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Đang lưu...</>
                  : isEdit ? ' Cập nhật' : ' Thêm mới'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

// ===== Customer Detail Modal =====
function CustomerDetailModal({ customer, orders, onClose }) {
  const customerOrders = orders.filter(o => o.customerId === customer.id);
  const totalSpent = customerOrders
    .filter(o => o.status === 'Completed')
    .reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Chi tiết khách hàng</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          {/* Info */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 16,
            padding: '16px 20px', background: 'var(--bg-input)',
            borderRadius: 12, marginBottom: 24, border: '1px solid var(--border)'
          }}>
            <div className="avatar" style={{ width: 52, height: 52, fontSize: 22 }}>
              {customer.name.charAt(0).toUpperCase()}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 17 }}>{customer.name}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 2 }}>
                SĐT: {customer.phone}
                {customer.email && <span style={{ marginLeft: 12 }}> {customer.email}</span>}
              </div>
              {customer.address && (
                <div style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 2 }}>
                  Địa chỉ: {customer.address}
                </div>
              )}
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Tổng chi tiêu</div>
              <div className="price" style={{ fontSize: 16 }}>{formatCurrency(totalSpent)}</div>
            </div>
          </div>

          {/* Orders */}
          <div style={{ fontWeight: 700, marginBottom: 12 }}>
            Lịch sử đơn hàng ({customerOrders.length})
          </div>
          {customerOrders.length === 0 ? (
            <div className="empty-state" style={{ padding: 20 }}>
              <div>Khách hàng chưa có đơn hàng nào</div>
            </div>
          ) : (
            <table className="table" style={{ border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
              <thead>
                <tr>
                  <th>Mã đơn</th>
                  <th>Sản phẩm</th>
                  <th>Tổng tiền</th>
                  <th>Trạng thái</th>
                  <th>Ngày tạo</th>
                </tr>
              </thead>
              <tbody>
                {customerOrders.map(order => (
                  <tr key={order.id}>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)' }}>
                      #{String(order.id).padStart(4, '0')}
                    </td>
                    <td style={{ fontSize: 13 }}>
                      {order.items?.map(i => `${i.productName} ×${i.quantity}`).join(', ')}
                    </td>
                    <td><span className="price">{formatCurrency(order.total)}</span></td>
                    <td>
                      <span className={`badge ${
                        order.status === 'Completed' ? 'badge-success' :
                        order.status === 'Pending' ? 'badge-warning' : 'badge-danger'
                      }`}>
                        {order.status === 'Completed' ? 'Hoàn thành' :
                         order.status === 'Pending' ? 'Chờ xử lý' : 'Đã huỷ'}
                      </span>
                    </td>
                    <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>{formatDate(order.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <div className="form-actions" style={{ borderTop: 'none', paddingTop: 16 }}>
            <button className="btn btn-ghost" onClick={onClose}>Đóng</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== Main Page =====
export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [modalCustomer, setModalCustomer] = useState(undefined); // undefined=closed, null=new, obj=edit
  const [detailCustomer, setDetailCustomer] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [c, o] = await Promise.all([customersApi.getAll(), ordersApi.getAll()]);
      setCustomers(c.data);
      setOrders(o.data);
    } catch {
      toast.error('Không thể tải dữ liệu');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useEffect(() => { setPage(1); }, [search]);

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search) ||
    (c.email || '').toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await customersApi.delete(deleteTarget.id);
      toast.success('Đã xoá khách hàng!');
      setDeleteTarget(null);
      fetchAll();
    } catch {
      toast.error('Xoá thất bại');
    } finally {
      setDeleting(false);
    }
  };

  // Đếm đơn hàng của từng khách
  const orderCount = cid => orders.filter(o => o.customerId === cid).length;
  const totalSpent = cid => orders
    .filter(o => o.customerId === cid && o.status === 'Completed')
    .reduce((sum, o) => sum + o.total, 0);

  if (loading) return <Loading text="Đang tải danh sách khách hàng..." />;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Quản lý khách hàng </div>
          <div className="page-subtitle">{customers.length} khách hàng đã đăng ký</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModalCustomer(null)}>
          Thêm khách hàng
        </button>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <span className="search-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </span>
          <input
            placeholder="Tìm theo tên, SĐT, email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"></div>
            <h3>Không tìm thấy khách hàng</h3>
            <p>Thêm khách hàng mới hoặc thay đổi từ khoá tìm kiếm</p>
          </div>
        ) : (
          <>
            <div className="table-wrapper">
              <table className="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Khách hàng</th>
                    <th>Số điện thoại</th>
                    <th>Email</th>
                    <th>Địa chỉ</th>
                    <th>Đơn hàng</th>
                    <th>Chi tiêu</th>
                    <th>Ngày tạo</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((customer, idx) => (
                    <tr key={customer.id}>
                      <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>
                        {(page - 1) * PAGE_SIZE + idx + 1}
                      </td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div className="avatar" style={{ width: 34, height: 34, fontSize: 13 }}>
                            {customer.name.charAt(0).toUpperCase()}
                          </div>
                          <span style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: 14 }}>
                            {customer.name}
                          </span>
                        </div>
                      </td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: 13 }}>
                        {customer.phone}
                      </td>
                      <td style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                        {customer.email || <span style={{ color: 'var(--text-muted)' }}>—</span>}
                      </td>
                      <td style={{ fontSize: 12, color: 'var(--text-muted)', maxWidth: 180 }}>
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {customer.address || '—'}
                        </div>
                      </td>
                      <td>
                        <span className="badge badge-info">{orderCount(customer.id)} đơn</span>
                      </td>
                      <td>
                        <span className="price">{formatCurrency(totalSpent(customer.id))}</span>
                      </td>
                      <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                        {formatDate(customer.createdAt)}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button
                            className="btn-icon"
                            title="Xem chi tiết"
                            onClick={() => setDetailCustomer(customer)}
                          >Chi tiết</button>
                          <button
                            className="btn-icon"
                            title="Sửa"
                            onClick={() => setModalCustomer(customer)}
                          >Sửa</button>
                          <button
                            className="btn-icon danger"
                            title="Xoá"
                            onClick={() => setDeleteTarget(customer)}
                          >Xoá</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              page={page} totalPages={totalPages}
              total={filtered.length} pageSize={PAGE_SIZE}
              onPageChange={setPage}
            />
          </>
        )}
      </div>

      {modalCustomer !== undefined && (
        <CustomerModal
          customer={modalCustomer}
          onClose={() => setModalCustomer(undefined)}
          onSaved={() => { setModalCustomer(undefined); fetchAll(); }}
        />
      )}

      {detailCustomer && (
        <CustomerDetailModal
          customer={detailCustomer}
          orders={orders}
          onClose={() => setDetailCustomer(null)}
        />
      )}

      <ConfirmDialog
        isOpen={!!deleteTarget}
        title="Xoá khách hàng"
        message={`Xoá khách hàng "${deleteTarget?.name}"? Dữ liệu sẽ không thể khôi phục.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        loading={deleting}
      />
    </div>
  );
}
