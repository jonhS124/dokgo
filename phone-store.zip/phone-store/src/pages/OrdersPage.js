import React, { useEffect, useState, useCallback } from 'react';
import { ordersApi, productsApi, customersApi } from '../services/api';
import { formatCurrency, formatDate, getOrderStatusBadge } from '../utils/format';
import Loading from '../components/Loading';
import Pagination from '../components/Pagination';
import ConfirmDialog from '../components/ConfirmDialog';
import toast from 'react-hot-toast';

const STATUSES = ['Tất cả', 'Pending', 'Completed', 'Cancelled'];
const PAGE_SIZE = 7;

// ===== Create Order Modal =====
function OrderModal({ onClose, onSaved, products, customers }) {
  const [form, setForm] = useState({
    customerId: '',
    customerName: '',
    items: [],
    note: '',
    status: 'Pending',
  });
  const [selectedProduct, setSelectedProduct] = useState('');
  const [selectedQty, setSelectedQty] = useState(1);
  const [saving, setSaving] = useState(false);

  const total = form.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCustomerChange = e => {
    const cid = Number(e.target.value);
    const customer = customers.find(c => c.id === cid);
    setForm(prev => ({
      ...prev,
      customerId: cid,
      customerName: customer ? customer.name : '',
    }));
  };

  const addItem = () => {
    if (!selectedProduct) return toast.error('Chọn sản phẩm');
    if (selectedQty < 1) return toast.error('Số lượng phải >= 1');

    const product = products.find(p => p.id === Number(selectedProduct));
    if (!product) return;

    if (product.quantity < selectedQty) {
      return toast.error(`Chỉ còn ${product.quantity} sản phẩm trong kho`);
    }

    const existing = form.items.findIndex(i => i.productId === product.id);
    if (existing >= 0) {
      // Cập nhật số lượng nếu đã có
      const updated = [...form.items];
      updated[existing].quantity += Number(selectedQty);
      setForm(prev => ({ ...prev, items: updated }));
    } else {
      setForm(prev => ({
        ...prev,
        items: [...prev.items, {
          productId: product.id,
          productName: product.name,
          price: product.price,
          quantity: Number(selectedQty),
        }],
      }));
    }
    setSelectedProduct('');
    setSelectedQty(1);
  };

  const removeItem = idx => {
    setForm(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.customerId) return toast.error('Vui lòng chọn khách hàng');
    if (form.items.length === 0) return toast.error('Vui lòng thêm ít nhất 1 sản phẩm');

    setSaving(true);
    try {
      await ordersApi.create({ ...form, total });
      toast.success(' Tạo đơn hàng thành công!');
      onSaved();
    } catch {
      toast.error('Tạo đơn hàng thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Tạo đơn hàng mới</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            {/* Customer */}
            <div className="form-group">
              <label className="form-label">Khách hàng <span>*</span></label>
              <select className="form-control" value={form.customerId} onChange={handleCustomerChange}>
                <option value="">-- Chọn khách hàng --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.name} — {c.phone}</option>
                ))}
              </select>
            </div>

            {/* Add Products */}
            <div className="form-group">
              <label className="form-label">Thêm sản phẩm</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 100px auto', gap: 8 }}>
                <select
                  className="form-control"
                  value={selectedProduct}
                  onChange={e => setSelectedProduct(e.target.value)}
                >
                  <option value="">-- Chọn sản phẩm --</option>
                  {products.filter(p => p.quantity > 0).map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} — {formatCurrency(p.price)} (còn {p.quantity})
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  className="form-control"
                  value={selectedQty}
                  onChange={e => setSelectedQty(Number(e.target.value))}
                  min={1}
                  placeholder="SL"
                />
                <button type="button" className="btn btn-primary" onClick={addItem}>
                  + Thêm
                </button>
              </div>
            </div>

            {/* Items list */}
            {form.items.length > 0 && (
              <div className="form-group">
                <label className="form-label">Danh sách sản phẩm đặt hàng</label>
                <div style={{
                  border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden'
                }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Sản phẩm</th>
                        <th>Đơn giá</th>
                        <th>SL</th>
                        <th>Thành tiền</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {form.items.map((item, idx) => (
                        <tr key={idx}>
                          <td className="primary">{item.productName}</td>
                          <td><span className="price">{formatCurrency(item.price)}</span></td>
                          <td>{item.quantity}</td>
                          <td><span className="price">{formatCurrency(item.price * item.quantity)}</span></td>
                          <td>
                            <button type="button" className="btn-icon danger" onClick={() => removeItem(idx)}>Xoá</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div style={{
                    padding: '12px 16px',
                    textAlign: 'right',
                    borderTop: '1px solid var(--border)',
                    background: 'rgba(255,255,255,0.02)'
                  }}>
                    <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Tổng cộng: </span>
                    <span className="price" style={{ fontSize: 18 }}>{formatCurrency(total)}</span>
                  </div>
                </div>
              </div>
            )}

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Trạng thái</label>
                <select className="form-control" value={form.status}
                  onChange={e => setForm(p => ({ ...p, status: e.target.value }))}>
                  <option value="Pending">Chờ xử lý</option>
                  <option value="Completed">Hoàn thành</option>
                  <option value="Cancelled">Đã huỷ</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Ghi chú</label>
                <input className="form-control" value={form.note}
                  onChange={e => setForm(p => ({ ...p, note: e.target.value }))}
                  placeholder="Ghi chú đơn hàng..." />
              </div>
            </div>

            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={onClose}>Huỷ</button>
              <button type="submit" className="btn btn-success" disabled={saving}>
                {saving ? <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Đang tạo...</> : ' Tạo đơn hàng'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

// ===== Edit Status Modal =====
function EditStatusModal({ order, onClose, onSaved }) {
  const [status, setStatus] = useState(order.status);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await ordersApi.update(order.id, { ...order, status });
      toast.success(' Cập nhật trạng thái thành công!');
      onSaved();
    } catch {
      toast.error('Cập nhật thất bại');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 400 }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Cập nhật trạng thái</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">
          <div style={{ marginBottom: 12, color: 'var(--text-muted)', fontSize: 13 }}>
            Đơn hàng #{order.id} — {order.customerName}
          </div>
          <div className="form-group">
            <label className="form-label">Trạng thái mới</label>
            <select className="form-control" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="Pending">Chờ xử lý</option>
              <option value="Completed">Hoàn thành</option>
              <option value="Cancelled">Đã huỷ</option>
            </select>
          </div>
          <div className="form-actions">
            <button className="btn btn-ghost" onClick={onClose}>Huỷ</button>
            <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? 'Đang lưu...' : ' Lưu'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ===== Main Page =====
export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Tất cả');
  const [page, setPage] = useState(1);
  const [showCreate, setShowCreate] = useState(false);
  const [editOrder, setEditOrder] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [o, p, c] = await Promise.all([
        ordersApi.getAll(),
        productsApi.getAll(),
        customersApi.getAll(),
      ]);
      setOrders(o.data);
      setProducts(p.data);
      setCustomers(c.data);
    } catch {
      toast.error('Không thể tải dữ liệu');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useEffect(() => { setPage(1); }, [search, statusFilter]);

  // Lọc
  const filtered = orders.filter(o => {
    const matchSearch =
      o.customerName?.toLowerCase().includes(search.toLowerCase()) ||
      String(o.id).includes(search);
    const matchStatus = statusFilter === 'Tất cả' || o.status === statusFilter;
    return matchSearch && matchStatus;
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Thống kê
  const totalRevenue = orders
    .filter(o => o.status === 'Completed')
    .reduce((sum, o) => sum + o.total, 0);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await ordersApi.delete(deleteTarget.id);
      toast.success('Đã xoá đơn hàng!');
      setDeleteTarget(null);
      fetchAll();
    } catch {
      toast.error('Xoá thất bại');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <Loading text="Đang tải đơn hàng..." />;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Quản lý đơn hàng</div>
          <div className="page-subtitle">
            {orders.length} đơn hàng · Doanh thu: <span style={{ color: 'var(--success)' }}>{formatCurrency(totalRevenue)}</span>
          </div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
           Tạo đơn hàng
        </button>
      </div>

      {/* Quick stats */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        {[
          { label: 'Tất cả', value: 'Tất cả', count: orders.length, cls: 'badge-gray' },
          { label: 'Chờ xử lý', value: 'Pending', count: orders.filter(o => o.status === 'Pending').length, cls: 'badge-warning' },
          { label: 'Hoàn thành', value: 'Completed', count: orders.filter(o => o.status === 'Completed').length, cls: 'badge-success' },
          { label: 'Đã huỷ', value: 'Cancelled', count: orders.filter(o => o.status === 'Cancelled').length, cls: 'badge-danger' },
        ].map(s => {
          const isActive = statusFilter === s.value;
          return (
            <div key={s.label}
              style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px',
                background: isActive ? 'var(--accent-light)' : 'var(--bg-card)', 
                border: `1px solid ${isActive ? 'var(--accent)' : 'var(--border)'}`, 
                borderRadius: 8,
                cursor: 'pointer', fontSize: 13,
                transition: 'all 0.2s ease',
                color: isActive ? 'var(--accent)' : 'var(--text-muted)'
              }}
              onClick={() => setStatusFilter(s.value)}
            >
              <span style={{ fontWeight: isActive ? 600 : 500 }}>{s.label}:</span>
              <span className={`badge ${s.cls}`} style={{ marginLeft: 0 }}>{s.count}</span>
            </div>
          );
        })}
      </div>

      <div className="toolbar">
        <div className="search-box">
          <span className="search-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </span>
          <input
            placeholder="Tìm theo tên khách hàng, mã đơn..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select className="filter-select" value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon"></div>
            <h3>Không có đơn hàng nào</h3>
            <p>Tạo đơn hàng mới để bắt đầu</p>
          </div>
        ) : (
          <>
            <div className="table-wrapper">
              <table className="table">
                <thead>
                  <tr>
                    <th>Mã đơn</th>
                    <th>Khách hàng</th>
                    <th>Sản phẩm</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Ngày tạo</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map(order => {
                    const badge = getOrderStatusBadge(order.status);
                    return (
                      <tr key={order.id}>
                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)' }}>
                          #{String(order.id).padStart(4, '0')}
                        </td>
                        <td className="primary">{order.customerName}</td>
                        <td>
                          <div className="order-items-preview">
                            {order.items?.slice(0, 2).map((item, i) => (
                              <div key={i} className="order-item-line">
                                {item.productName} × {item.quantity}
                              </div>
                            ))}
                            {order.items?.length > 2 && (
                              <div className="order-item-line">+{order.items.length - 2} sản phẩm khác</div>
                            )}
                          </div>
                        </td>
                        <td><span className="price">{formatCurrency(order.total)}</span></td>
                        <td>
                          <span
                            className={`badge ${badge.cls}`}
                            style={{ cursor: 'pointer' }}
                            title="Click để cập nhật"
                            onClick={() => setEditOrder(order)}
                          >
                            {badge.label}
                          </span>
                        </td>
                        <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                          {formatDate(order.createdAt)}
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="btn-icon" title="Cập nhật" onClick={() => setEditOrder(order)}>Sửa</button>
                            <button className="btn-icon danger" title="Xoá" onClick={() => setDeleteTarget(order)}>Xoá</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination
              page={page} totalPages={totalPages}
              total={filtered.length} pageSize={PAGE_SIZE}
              onPageChange={setPage}
            />
          </>
        )}
      </div>

      {showCreate && (
        <OrderModal
          products={products}
          customers={customers}
          onClose={() => setShowCreate(false)}
          onSaved={() => { setShowCreate(false); fetchAll(); }}
        />
      )}

      {editOrder && (
        <EditStatusModal
          order={editOrder}
          onClose={() => setEditOrder(null)}
          onSaved={() => { setEditOrder(null); fetchAll(); }}
        />
      )}

      <ConfirmDialog
        isOpen={!!deleteTarget}
        title="Xoá đơn hàng"
        message={`Xoá đơn hàng #${deleteTarget?.id} của ${deleteTarget?.customerName}?`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        loading={deleting}
      />
    </div>
  );
}
