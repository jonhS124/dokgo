import React from 'react';

/**
 * ConfirmDialog: Hộp thoại xác nhận xoá / huỷ
 */
export default function ConfirmDialog({ isOpen, title, message, onConfirm, onCancel, loading }) {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onCancel}>
      <div
        className="modal confirm-dialog"
        onClick={e => e.stopPropagation()}
      >
        <div className="modal-body" style={{ textAlign: 'center', padding: '32px 28px' }}>
          <div className="confirm-icon">⚠️</div>
          <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>{title}</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 28 }}>{message}</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button className="btn btn-ghost" onClick={onCancel} disabled={loading}>
              Huỷ bỏ
            </button>
            <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
              {loading ? (
                <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> Đang xoá...</>
              ) : '🗑 Xác nhận xoá'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
