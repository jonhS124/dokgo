import React from 'react';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-cols">
          <div className="footer-col">
            <h3>Hệ thống cửa hàng PhoneStore</h3>
            <p><strong>Hà Nội:</strong> 999 Phố Vui Vẻ, Quận Đống Đa</p>
            <p><strong>TP.HCM:</strong> 888 Đường Bất Ngờ, Quận 1</p>
            <p><strong>Đà Nẵng:</strong> 777 Đại Lộ Mộng Mơ, Sơn Trà</p>
            <p className="footer-hotline">Hotline: 083.425.3689</p>
          </div>
          <div className="footer-col">
            <h3>Quy định - Chính sách</h3>
            <a href="#">Chính sách bảo hành</a>
            <a href="#">Chính sách đổi trả</a>
            <a href="#">Chính sách bảo mật</a>
            <a href="#">Hướng dẫn mua hàng trả góp</a>
          </div>
          <div className="footer-col">
            <h3>Hỗ trợ khách hàng</h3>
            <a href="#">Tra cứu đơn hàng</a>
            <a href="#">Trung tâm bảo hành</a>
            <a href="#">Thanh toán và giao hàng</a>
            <a href="#">Câu hỏi thường gặp</a>
          </div>
        </div>
        <div className="footer-bottom">
          &copy; {new Date().getFullYear()} PhoneStore. Bản quyền thuộc về PhoneStore.
        </div>
      </div>
    </footer>
  );
}
