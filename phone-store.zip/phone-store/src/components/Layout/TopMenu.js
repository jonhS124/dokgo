import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import './TopMenu.css';

const BRANDS = [
  'Apple',
  'Samsung',
  'Xiaomi',
  'OPPO',
  'Vivo',
  'Realme',
  'Nokia',
  'Phụ kiện'
];

export default function TopMenu() {
  const [searchParams] = useSearchParams();
  const currentBrand = searchParams.get('brand') || 'Tất cả';

  return (
    <nav className="top-menu">
      <div className="top-menu-container">
        <div className="top-menu-list">
          <Link 
            to="/products"
            className={`top-menu-item ${currentBrand === 'Tất cả' ? 'active' : ''}`}
          >
            Tất cả
          </Link>
          {BRANDS.map(brand => (
            <Link 
              key={brand} 
              to={`/products?brand=${brand}`} 
              className={`top-menu-item ${currentBrand === brand ? 'active' : ''}`}
            >
              {brand}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
