import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../../utils/AuthContext';
import './ProfileLayout.css';

const PROFILE_LINKS = [
  { path: '/profile', label: 'Thông tin khách hàng' },
  { path: '/my-orders', label: 'Đơn đặt hàng' },
  { path: '/purchase-history', label: 'Lịch sử mua hàng' },
  { path: '/receipts', label: 'Phiếu nhận máy' },
];

export default function ProfileLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="profile-layout-container">
      {/* Cột trái */}
      <div className="profile-sidebar">
        <div className="profile-sidebar-header">
          <div className="profile-avatar">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="profile-info">
            <span className="profile-role">Khách hàng</span>
            <strong className="profile-name">{user.name}</strong>
          </div>
        </div>

        <nav className="profile-nav">
          {PROFILE_LINKS.map(link => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) => `profile-nav-item ${isActive ? 'active' : ''}`}
              end={link.path === '/profile'}
            >
              {link.label}
            </NavLink>
          ))}
          <button onClick={handleLogout} className="profile-nav-item logout-btn" style={{ borderTop: '1px solid #f1f5f9' }}>
            Thoát
          </button>
        </nav>
      </div>

      {/* Cột phải - Nội dung */}
      <div className="profile-content">
        <Outlet />
      </div>
    </div>
  );
}
