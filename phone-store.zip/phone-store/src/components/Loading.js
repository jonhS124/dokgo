import React from 'react';

export default function Loading({ text = 'Đang tải...' }) {
  return (
    <div className="loading-container">
      <div className="spinner" />
      <div className="loading-text">{text}</div>
    </div>
  );
}
