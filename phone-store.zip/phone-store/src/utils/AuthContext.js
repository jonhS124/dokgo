import React, { createContext, useContext, useState } from 'react';
import axios from 'axios';

const AuthContext = createContext(null);
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

/**
 * AuthProvider: Quản lý trạng thái xác thực toàn cục
 * Đăng nhập & đăng ký qua JSON Server (/users)
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('phone_store_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [loading, setLoading] = useState(false);

  // Login — tìm user trong JSON Server
  const login = async (username, password) => {
    setLoading(true);
    try {
      const res = await axios.get(`${API_URL}/users`, {
        params: { username, password }
      });

      if (res.data.length > 0) {
        const found = res.data[0];
        const userData = {
          id: found.id,
          username: found.username,
          name: found.name,
          email: found.email,
          phone: found.phone,
          gender: found.gender,
          dob: found.dob,
          role: found.role,
          avatar: found.avatar || found.name?.charAt(0)?.toUpperCase() || 'U',
          loginAt: new Date().toISOString()
        };
        setUser(userData);
        localStorage.setItem('phone_store_user', JSON.stringify(userData));
        setLoading(false);
        return { success: true };
      }

      setLoading(false);
      return { success: false, message: 'Sai tên đăng nhập hoặc mật khẩu' };
    } catch {
      setLoading(false);
      return { success: false, message: 'Không thể kết nối đến server' };
    }
  };

  // Register — tạo user mới trong JSON Server
  const register = async ({ name, email, phone, username, password }) => {
    setLoading(true);
    try {
      // Fetch tất cả user để kiểm tra chính xác phía client
      // Tránh lỗi JSON Server filter trả về tất cả nếu field chưa tồn tại
      const allUsersRes = await axios.get(`${API_URL}/users`);
      const allUsers = allUsersRes.data;

      // Kiểm tra username đã tồn tại chưa
      if (allUsers.some(u => u.username === username)) {
        setLoading(false);
        return { success: false, message: 'Tên đăng nhập đã tồn tại' };
      }

      // Kiểm tra email đã tồn tại chưa
      if (allUsers.some(u => u.email === email)) {
        setLoading(false);
        return { success: false, message: 'Email này đã được sử dụng' };
      }

      // Sinh ID duy nhất tránh đụng hàng giữa users và customers
      const uniqueId = Date.now().toString();

      // Tạo user mới
      const res = await axios.post(`${API_URL}/users`, {
        id: uniqueId,
        username,
        password,
        name,
        email,
        phone,
        role: 'user',
        avatar: name.charAt(0).toUpperCase(),
        verified: true,
        createdAt: new Date().toISOString().split('T')[0]
      });

      // Tạo hồ sơ Khách hàng tương ứng bên CSDL /customers
      await axios.post(`${API_URL}/customers`, {
        id: res.data.id,
        name: res.data.name,
        email: res.data.email,
        phone: res.data.phone || '',
        address: '',
        status: 'active',
        ordersCount: 0,
        totalSpent: 0,
        createdAt: new Date().toISOString().split('T')[0]
      });

      const userData = {
        id: res.data.id,
        username: res.data.username,
        name: res.data.name,
        email: res.data.email,
        phone: res.data.phone,
        gender: res.data.gender,
        dob: res.data.dob,
        role: res.data.role,
        avatar: res.data.avatar,
        loginAt: new Date().toISOString()
      };
      setUser(userData);
      localStorage.setItem('phone_store_user', JSON.stringify(userData));
      setLoading(false);
      return { success: true };
    } catch {
      setLoading(false);
      return { success: false, message: 'Không thể kết nối đến server' };
    }
  };

  // Logout
  const logout = () => {
    setUser(null);
    localStorage.removeItem('phone_store_user');
  };

  // Update Profile
  const updateProfile = async (id, updatedData) => {
    setLoading(true);
    try {
      const userRes = await axios.get(`${API_URL}/users/${id}`);
      const existingUser = userRes.data;
      const newUserData = { ...existingUser, ...updatedData };
      await axios.put(`${API_URL}/users/${id}`, newUserData);

      try {
        const custRes = await axios.get(`${API_URL}/customers/${id}`);
        const existingCust = custRes.data;
        await axios.put(`${API_URL}/customers/${id}`, { ...existingCust, ...updatedData });
      } catch (err) {
        // Customer might not exist or other error, ignore
      }

      const userData = {
        id: newUserData.id,
        username: newUserData.username,
        name: newUserData.name,
        email: newUserData.email,
        phone: newUserData.phone,
        gender: newUserData.gender,
        dob: newUserData.dob,
        role: newUserData.role,
        avatar: newUserData.avatar,
        loginAt: new Date().toISOString()
      };
      
      setUser(userData);
      localStorage.setItem('phone_store_user', JSON.stringify(userData));
      setLoading(false);
      return { success: true };
    } catch (err) {
      setLoading(false);
      return { success: false, message: 'Lỗi khi cập nhật thông tin' };
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateProfile, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook để dùng Auth
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth phải được dùng trong AuthProvider');
  return ctx;
}
