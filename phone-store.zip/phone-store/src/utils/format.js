/**
 * Định dạng tiền VNĐ
 */
export function formatCurrency(amount) {
  if (!amount && amount !== 0) return '—';
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(amount);
}

/**
 * Định dạng ngày tháng tiếng Việt
 */
export function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric'
  });
}

/**
 * Định dạng ngày giờ
 */
export function formatDateTime(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleString('vi-VN');
}

/**
 * Lấy nhãn trạng thái đơn hàng
 */
export function getOrderStatusBadge(status) {
  const map = {
    'Pending':   { label: 'Chờ xử lý', cls: 'badge-warning' },
    'Completed': { label: 'Hoàn thành', cls: 'badge-success' },
    'Cancelled': { label: 'Đã huỷ',    cls: 'badge-danger'  },
  };
  return map[status] || { label: status, cls: 'badge-gray' };
}

/**
 * Truncate text
 */
export function truncate(str, len = 40) {
  if (!str) return '';
  return str.length > len ? str.slice(0, len) + '…' : str;
}

/**
 * Tạo ID ngẫu nhiên đơn giản
 */
export function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

/**
 * Debounce function
 */
export function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
